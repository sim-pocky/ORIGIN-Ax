"""Pseudo-ST benchmark from real cell-level AnnData.

This uses real malignant and TME expression profiles, then mixes them into
pseudo-bins with known malignant purity and known malignant state coordinates.
It is a bridge between fully synthetic sweeps and real Visium HD application.
"""
from __future__ import annotations

import argparse
import os
import warnings

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.decomposition import FastICA, PCA
from sklearn.neighbors import NearestNeighbors

from baselines import METHODS
from metrics import score_result

warnings.filterwarnings("ignore")

HERE = os.path.dirname(__file__)
OUT = os.path.join(HERE, "results")


def _to_dense(x):
    if sparse.issparse(x):
        return x.toarray()
    return np.asarray(x)


def _cpm(x: np.ndarray) -> np.ndarray:
    lib = x.sum(axis=1, keepdims=True)
    lib[lib == 0] = 1
    return x / lib * 1e4


def _zscore(x: np.ndarray) -> np.ndarray:
    return (x - x.mean(axis=0)) / (x.std(axis=0) + 1e-9)


def _read_matrix(adata, layer: str | None) -> np.ndarray:
    if layer and layer in adata.layers:
        return _to_dense(adata.layers[layer])
    return _to_dense(adata.X)


def _top_variable_genes(x: np.ndarray, max_genes: int) -> np.ndarray:
    if x.shape[1] <= max_genes:
        return np.arange(x.shape[1])
    mu = x.mean(axis=0)
    var = x.var(axis=0)
    score = var / (mu + 1e-6)
    return np.argsort(-score)[:max_genes]


def _truth_malignant_axes(x_mal_cpm: np.ndarray, k: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    n_pc = min(40, x_mal_cpm.shape[0] - 1, x_mal_cpm.shape[1] - 1)
    z = PCA(n_pc, random_state=seed).fit_transform(_zscore(x_mal_cpm))
    scores = FastICA(k, random_state=seed, max_iter=1000, tol=1e-3).fit_transform(z)
    loadings = (_zscore(x_mal_cpm).T @ _zscore(scores)) / x_mal_cpm.shape[0]
    return scores, loadings


def make_pseudo_st(
    path: str,
    label_key: str = "cell_type",
    malignant_label: str = "Malignant",
    layer: str | None = None,
    n_bins: int = 1200,
    k: int = 3,
    ce: int = 3,
    max_genes: int = 800,
    purity_a: float = 2.0,
    purity_b: float = 2.0,
    cnv_noise: float = 0.10,
    seed: int = 0,
) -> dict:
    rng = np.random.default_rng(seed)
    a = ad.read_h5ad(path)
    if label_key not in a.obs:
        raise KeyError(f"{label_key!r} not found in obs. Available: {list(a.obs.columns)[:30]}")

    labels = a.obs[label_key].astype(str).to_numpy()
    mal_mask = labels == malignant_label
    env_mask = ~mal_mask
    if mal_mask.sum() < 100 or env_mask.sum() < 100:
        raise ValueError(f"Need >=100 malignant and env cells, got malignant={mal_mask.sum()} env={env_mask.sum()}")

    x_raw = _read_matrix(a, layer)
    x_cpm_all = _cpm(np.clip(x_raw, 0, None))
    genes = _top_variable_genes(x_cpm_all, max_genes)
    x_cpm_all = x_cpm_all[:, genes]
    var_names = np.asarray(a.var_names)[genes]

    mal_idx = np.where(mal_mask)[0]
    env_idx = np.where(env_mask)[0]
    x_mal = x_cpm_all[mal_idx]
    x_env = x_cpm_all[env_idx]

    mal_scores, mal_loadings = _truth_malignant_axes(x_mal, k, seed)
    mal_blocks = [np.argsort(-np.abs(mal_loadings[:, j]))[:30] for j in range(k)]

    mal_mean = x_mal.mean(axis=0)
    env_mean = x_env.mean(axis=0)
    env_marker = np.argsort(-(env_mean + 1) / (mal_mean + 1))[: max(30, 10 * ce)]
    env_blocks = [env_marker[i * 30:(i + 1) * 30] for i in range(max(1, min(ce, len(env_marker) // 30)))]

    purity = rng.beta(purity_a, purity_b, size=n_bins)
    mal_pick = rng.integers(0, len(mal_idx), size=n_bins)
    # Average several TME cells to mimic local multicellular background.
    env_pick = rng.integers(0, len(env_idx), size=(n_bins, 4))
    mal_expr = x_mal[mal_pick]
    env_expr = x_env[env_pick].mean(axis=1)
    cpm = purity[:, None] * mal_expr + (1 - purity)[:, None] * env_expr
    x_log = np.log1p(cpm)
    z_m = mal_scores[mal_pick]

    p_cnv = np.clip(purity + rng.normal(0, cnv_noise, size=n_bins), 0, 1)

    if "spatial" in a.obsm:
        coords_all = np.asarray(a.obsm["spatial"])
        coords = purity[:, None] * coords_all[mal_idx[mal_pick]]
        coords += (1 - purity)[:, None] * coords_all[env_idx[env_pick]].mean(axis=1)
    else:
        coords = rng.uniform(0, 1, size=(n_bins, 2))
    nn = NearestNeighbors(n_neighbors=min(9, n_bins)).fit(coords)
    _, idx = nn.kneighbors(coords)
    nbr = [row[1:] for row in idx]

    return {
        "X": x_log,
        "CPM": cpm,
        "coords": coords,
        "nbr": nbr,
        "purity": purity,
        "p_cnv": p_cnv,
        "Z_m": z_m,
        "mal_blocks": [np.asarray(b, dtype=int) for b in mal_blocks],
        "env_blocks": [np.asarray(b, dtype=int) for b in env_blocks],
        "var_names": var_names,
        "source_path": path,
        "label_key": label_key,
        "malignant_label": malignant_label,
    }


def run_pseudo_benchmark(sim: dict, seed: int = 0, input_layer: str = "cpm") -> pd.DataFrame:
    x = sim["CPM"] if input_layer == "cpm" else sim["X"]
    k = sim["Z_m"].shape[1]
    ce = max(1, len(sim["env_blocks"]))
    rows = []
    for name, fn in METHODS.items():
        res = fn(x, k=k, ce=ce, p_cnv=sim["p_cnv"], nbr=sim["nbr"], seed=seed)
        rows.append({
            "input": input_layer,
            "method": name,
            "mode": res.get("mode", ""),
            **res.get("diagnostics", {}),
            **score_result(res, sim),
        })
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default="data/tumor_st/xenium_melanoma/processed.h5ad")
    parser.add_argument("--label-key", default="cell_type")
    parser.add_argument("--malignant-label", default="Malignant")
    parser.add_argument("--layer", default=None)
    parser.add_argument("--n-bins", type=int, default=1200)
    parser.add_argument("--max-genes", type=int, default=800)
    parser.add_argument("--purity-a", type=float, default=2.0)
    parser.add_argument("--purity-b", type=float, default=2.0)
    parser.add_argument("--cnv-noise", type=float, default=0.10)
    parser.add_argument("--input", choices=["cpm", "log", "both"], default="cpm")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--out", default=None, help="output CSV path")
    args = parser.parse_args()

    os.makedirs(OUT, exist_ok=True)
    sim = make_pseudo_st(
        path=args.path,
        label_key=args.label_key,
        malignant_label=args.malignant_label,
        layer=args.layer,
        n_bins=args.n_bins,
        max_genes=args.max_genes,
        purity_a=args.purity_a,
        purity_b=args.purity_b,
        cnv_noise=args.cnv_noise,
        seed=args.seed,
    )
    layers = ["cpm", "log"] if args.input == "both" else [args.input]
    df = pd.concat([run_pseudo_benchmark(sim, seed=args.seed, input_layer=layer) for layer in layers], ignore_index=True)
    out_path = args.out or os.path.join(OUT, "pseudo_st_scores.csv")
    df.to_csv(out_path, index=False)
    metric_cols = ["acc", "recall", "overall", "acc_p50", "recall_p50", "overall_p50", "contam_fdr", "dep"]
    print(df.groupby(["input", "method"])[metric_cols].mean().sort_values("overall", ascending=False).round(3).to_string())
    print(f"\n[out] {out_path}")


if __name__ == "__main__":
    main()
