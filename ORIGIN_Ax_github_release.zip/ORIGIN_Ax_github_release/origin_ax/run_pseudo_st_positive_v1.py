"""Semi-real pseudo-ST ORIGIN-Ax v1 run."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../cnv_deconv")))
from pseudo_st import make_pseudo_st  # noqa: E402

from core import OriginAxConfig, make_gene_weight_table, rank01
from run_common import run_origin_ax

HERE = Path(__file__).resolve().parent
OUT = HERE / "results_v1" / "pseudo_st_positive"


def _smooth(x: np.ndarray, coords: np.ndarray, steps: int = 5) -> np.ndarray:
    nn = NearestNeighbors(n_neighbors=min(13, len(coords))).fit(coords)
    _, idx = nn.kneighbors(coords)
    out = x.astype(float).copy()
    for _ in range(steps):
        out = 0.6 * out + 0.4 * out[idx[:, 1:]].mean(axis=1)
    return rank01(out)


def run_condition(args: argparse.Namespace, name: str, purity_a: float, purity_b: float) -> dict:
    sim = make_pseudo_st(
        path=args.path,
        label_key=args.label_key,
        malignant_label=args.malignant_label,
        n_bins=args.n_bins,
        max_genes=args.max_genes,
        k=3,
        purity_a=purity_a,
        purity_b=purity_b,
        cnv_noise=0.08,
        seed=args.seed,
    )
    genes = np.asarray(sim["var_names"]).astype(str)
    target = np.zeros(len(genes))
    tme = np.zeros(len(genes))
    heldout: set[str] = set()
    for block in sim["mal_blocks"]:
        block = np.asarray(block, dtype=int)
        target[block[::2]] = 1.0
        heldout.update(genes[block[1::2]].astype(str))
    for block in sim["env_blocks"]:
        tme[np.asarray(block, dtype=int)] = 1.0
    gw_table = make_gene_weight_table(genes, target, tme_penalty=tme, source="pseudo_st_anchor_split")
    gw = {
        "target_support": gw_table["target_support"].to_numpy(float),
        "normal_epithelial_penalty": gw_table["normal_epithelial_penalty"].to_numpy(float),
        "tme_penalty": gw_table["tme_penalty"].to_numpy(float),
        "final_weight": gw_table["final_weight"].to_numpy(float),
    }
    rng = np.random.default_rng(args.seed + 101)
    clone = _smooth(sim["Z_m"][:, 0] + 0.25 * sim["p_cnv"] + 0.10 * rng.standard_normal(args.n_bins), sim["coords"])
    niche = _smooth(np.mean(sim["CPM"][:, np.concatenate(sim["env_blocks"])], axis=1), sim["coords"], steps=2)
    out_dir = OUT / name
    _, summary = run_origin_ax(
        dataset=f"pseudo_st_{name}",
        x=sim["CPM"],
        genes=genes,
        coords=sim["coords"],
        clone=clone,
        niche=niche,
        gene_weights=gw,
        truth_eval_genes=heldout,
        out_dir=out_dir,
        config=OriginAxConfig(k=args.axis_k),
    )
    return {"condition": name, "purity_a": purity_a, "purity_b": purity_b, **summary}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default="data/tumor_st/xenium_melanoma/processed.h5ad")
    parser.add_argument("--label-key", default="cell_type")
    parser.add_argument("--malignant-label", default="Malignant")
    parser.add_argument("--n-bins", type=int, default=800)
    parser.add_argument("--max-genes", type=int, default=350)
    parser.add_argument("--axis-k", type=int, default=5)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    rows = [
        run_condition(args, "balanced", 2.0, 2.0),
        run_condition(args, "low_purity", 1.4, 4.0),
    ]
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "summary.csv", index=False)
    print(df.to_string(index=False))
    if not bool((df["n_passed_truth_mal_axis"] >= 1).all()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
