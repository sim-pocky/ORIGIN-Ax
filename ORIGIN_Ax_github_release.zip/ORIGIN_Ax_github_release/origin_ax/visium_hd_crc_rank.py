"""Rank malignant-state recovery methods on real Visium HD CRC 8um bins.

There is no ground-truth malignant state on real tissue, so this script reports
diagnostic rankings rather than accuracy:
  - stability: gene-half reproducibility of bin scores,
  - contamination FDR: top-loading genes look more TME than epithelial,
  - dependence: mean absolute component Spearman correlation,
  - Moran's I: spatial smoothness of recovered axes.

Purity is a marker-derived epithelial-vs-TME proxy by default, not CNV purity.
This is sufficient for a real-data sanity check, but should not be described as
CNV-guided until a proper inferCNV/SpaCET purity vector is supplied.
"""
from __future__ import annotations

import argparse
import gzip
import os
import warnings

import h5py
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmread
from scipy.optimize import linear_sum_assignment
from scipy.stats import spearmanr
from sklearn.neighbors import NearestNeighbors

from baselines import METHODS

warnings.filterwarnings("ignore")

HERE = os.path.dirname(__file__)
ROOT = os.path.abspath(os.path.join(HERE, "../../.."))
DEFAULT_B = os.path.join(ROOT, "data/visium_hd_crc/binned_outputs/square_008um")
OUT = os.path.join(HERE, "results")

EPI = {
    "EPCAM", "KRT8", "KRT18", "KRT19", "KRT20", "CDX2", "CEACAM5", "CEACAM6",
    "CEACAM7", "ELF3", "TSPAN8", "MUC2", "TFF3", "OLFM4", "LGR5", "ASCL2",
    "SOX9", "MKI67", "TOP2A", "MS4A12", "SLC26A3", "AQP8", "REG4",
}
FIB = {
    "COL1A1", "COL1A2", "COL3A1", "COL5A1", "COL6A1", "COL6A2", "COL6A3",
    "DCN", "LUM", "AEBP1", "FN1", "PDGFRB", "FAP", "POSTN", "VCAN", "MMP2",
    "SPARC", "VIM",
}
IMM = {
    "PTPRC", "CD3D", "CD3E", "CD68", "LYZ", "MS4A1", "CD79A", "JCHAIN",
    "MZB1", "IGKC", "IGHM", "IGHG1", "C1QA", "C1QB", "C1QC", "TYROBP",
    "FCER1G", "AIF1", "CD74",
}
ENDO = {"PECAM1", "VWF", "CLDN5", "CDH5", "PLVAP", "KDR", "FLT1"}
TME = FIB | IMM | ENDO


def _read_tsv_gz(path: str) -> list[list[str]]:
    with gzip.open(path, "rt") as fh:
        return [line.rstrip("\n").split("\t") for line in fh]


def load_10x_dir(base: str, max_bins: int, seed: int) -> tuple[sparse.csr_matrix, np.ndarray, np.ndarray, np.ndarray]:
    h5 = os.path.join(base, "filtered_feature_bc_matrix.h5")
    if os.path.exists(h5):
        return load_10x_h5_sample(h5, os.path.join(base, "spatial/tissue_positions.parquet"), max_bins, seed)
    mtx = os.path.join(base, "filtered_feature_bc_matrix/matrix.mtx.gz")
    features = os.path.join(base, "filtered_feature_bc_matrix/features.tsv.gz")
    barcodes = os.path.join(base, "filtered_feature_bc_matrix/barcodes.tsv.gz")
    pos_path = os.path.join(base, "spatial/tissue_positions.parquet")
    if not os.path.exists(mtx):
        raise FileNotFoundError(mtx)
    x = mmread(mtx).tocsr().T  # bins x genes
    genes = np.array([r[1] if len(r) > 1 else r[0] for r in _read_tsv_gz(features)], dtype=object)
    bcs = np.array([r[0] for r in _read_tsv_gz(barcodes)], dtype=object)
    pos = pd.read_parquet(pos_path).set_index("barcode")
    coords = pos.loc[bcs, ["pxl_col_in_fullres", "pxl_row_in_fullres"]].to_numpy(float)

    counts = np.asarray(x.sum(axis=1)).ravel()
    keep = (counts >= 200) & np.isfinite(coords).all(axis=1)
    x, coords, bcs = x[keep], coords[keep], bcs[keep]
    if x.shape[0] > max_bins:
        rng = np.random.default_rng(seed)
        idx = np.sort(rng.choice(x.shape[0], max_bins, replace=False))
        x, coords, bcs = x[idx], coords[idx], bcs[idx]
    gene_keep = np.asarray((x > 0).sum(axis=0)).ravel() >= 10
    x = x[:, gene_keep].tocsr()
    genes = genes[gene_keep]
    return x, genes, bcs, coords


def _decode_array(x) -> np.ndarray:
    arr = np.asarray(x)
    return np.array([v.decode() if isinstance(v, bytes) else str(v) for v in arr], dtype=object)


def load_10x_h5_sample(h5_path: str, pos_path: str, max_bins: int, seed: int) -> tuple[sparse.csr_matrix, np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    with h5py.File(h5_path, "r") as f:
        g = f["matrix"]
        barcodes = _decode_array(g["barcodes"][:])
        genes = _decode_array(g["features/name"][:])
        indptr = g["indptr"][:]
        n_barcodes = len(barcodes)
        sample_n = min(max_bins * 3, n_barcodes)
        candidates = np.sort(rng.choice(n_barcodes, sample_n, replace=False))
        rows, cols, vals = [], [], []
        for out_i, col_i in enumerate(candidates):
            start, end = int(indptr[col_i]), int(indptr[col_i + 1])
            if end <= start:
                continue
            idx = g["indices"][start:end]
            dat = g["data"][start:end]
            rows.append(np.full(len(dat), out_i, dtype=np.int32))
            cols.append(idx.astype(np.int32))
            vals.append(dat.astype(np.float32))
        if not vals:
            raise ValueError("No nonzero sampled bins from h5")
        x = sparse.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
                              shape=(len(candidates), len(genes)))
        bcs = barcodes[candidates]

    pos = pd.read_parquet(pos_path).set_index("barcode")
    in_pos = pd.Index(bcs).isin(pos.index)
    x = x[in_pos]
    bcs = bcs[in_pos]
    coords = pos.loc[bcs, ["pxl_col_in_fullres", "pxl_row_in_fullres"]].to_numpy(float)
    counts = np.asarray(x.sum(axis=1)).ravel()
    keep = (counts >= 200) & np.isfinite(coords).all(axis=1)
    x, coords, bcs = x[keep], coords[keep], bcs[keep]
    if x.shape[0] > max_bins:
        idx = np.sort(rng.choice(x.shape[0], max_bins, replace=False))
        x, coords, bcs = x[idx], coords[idx], bcs[idx]
    gene_keep = np.asarray((x > 0).sum(axis=0)).ravel() >= 10
    return x[:, gene_keep].tocsr(), genes[gene_keep], bcs, coords


def cpm(x: sparse.csr_matrix) -> np.ndarray:
    lib = np.asarray(x.sum(axis=1)).ravel()
    lib[lib == 0] = 1
    return x.multiply(1e4 / lib[:, None]).toarray()


def marker_score(x_cpm: np.ndarray, genes: np.ndarray, markers: set[str]) -> np.ndarray:
    idx = np.array([i for i, g in enumerate(genes) if str(g) in markers], dtype=int)
    if len(idx) == 0:
        return np.zeros(x_cpm.shape[0])
    return np.log1p(x_cpm[:, idx]).mean(axis=1)


def purity_proxy(x_cpm: np.ndarray, genes: np.ndarray) -> tuple[np.ndarray, pd.DataFrame]:
    epi = marker_score(x_cpm, genes, EPI)
    fib = marker_score(x_cpm, genes, FIB)
    imm = marker_score(x_cpm, genes, IMM)
    endo = marker_score(x_cpm, genes, ENDO)
    tme = np.maximum.reduce([fib, imm, endo])
    raw = epi - tme
    ranks = pd.Series(raw).rank(method="average").to_numpy()
    p = (ranks - 1) / max(1, len(ranks) - 1)
    diag = pd.DataFrame({"epi_score": epi, "fib_score": fib, "imm_score": imm, "endo_score": endo, "p_marker_proxy": p})
    return p.astype(float), diag


def top_hvg(x_cpm: np.ndarray, max_genes: int) -> np.ndarray:
    mu = x_cpm.mean(axis=0)
    var = x_cpm.var(axis=0)
    score = var / (mu + 1e-6)
    return np.argsort(-score)[: min(max_genes, x_cpm.shape[1])]


def loadings(scores: np.ndarray, x: np.ndarray) -> np.ndarray:
    sz = (scores - scores.mean(axis=0)) / (scores.std(axis=0) + 1e-9)
    xz = (x - x.mean(axis=0)) / (x.std(axis=0) + 1e-9)
    return (xz.T @ sz) / x.shape[0]


def component_dependence(scores: np.ndarray) -> float:
    vals = []
    for i in range(scores.shape[1]):
        for j in range(i + 1, scores.shape[1]):
            r = spearmanr(scores[:, i], scores[:, j]).statistic
            vals.append(abs(float(r)) if np.isfinite(r) else 0.0)
    return float(np.mean(vals)) if vals else 0.0


def contamination_fdr(load: np.ndarray, genes: np.ndarray, top_n: int = 30) -> tuple[float, float]:
    bad = 0
    epi_fracs = []
    for j in range(load.shape[1]):
        top = set(genes[np.argsort(-np.abs(load[:, j]))[:top_n]])
        epi = len(top & EPI)
        tme = len(top & TME)
        epi_fracs.append(epi / top_n)
        if tme > epi:
            bad += 1
    return bad / max(1, load.shape[1]), float(np.mean(epi_fracs))


def moran_mean(scores: np.ndarray, coords: np.ndarray, k: int = 8) -> float:
    nn = NearestNeighbors(n_neighbors=min(k + 1, len(coords))).fit(coords)
    _, idx = nn.kneighbors(coords)
    vals = []
    for j in range(scores.shape[1]):
        z = scores[:, j] - scores[:, j].mean()
        den = float((z * z).sum())
        if den < 1e-9:
            vals.append(0.0)
            continue
        num = 0.0
        w = 0
        for i in range(len(z)):
            nb = idx[i, 1:]
            num += float((z[i] * z[nb]).sum())
            w += len(nb)
        vals.append((len(z) / max(1, w)) * num / den)
    return float(np.mean(vals)) if vals else 0.0


def stability(fn, x: np.ndarray, k: int, ce: int, p: np.ndarray, seed: int) -> float:
    rng = np.random.default_rng(seed)
    perm = rng.permutation(x.shape[1])
    a = perm[: x.shape[1] // 2]
    b = perm[x.shape[1] // 2:]
    try:
        ra = fn(x[:, a], k=k, ce=ce, p_cnv=p, seed=seed)
        rb = fn(x[:, b], k=k, ce=ce, p_cnv=p, seed=seed + 1)
        sa, sb = ra["scores"], rb["scores"]
        mat = np.abs(np.array([[np.corrcoef(sa[:, i], sb[:, j])[0, 1] for j in range(sb.shape[1])] for i in range(sa.shape[1])]))
        mat = np.nan_to_num(mat)
        ri, ci = linear_sum_assignment(-mat)
        return float(mat[ri, ci].mean())
    except Exception:
        return 0.0


def run_rank(x_cpm: np.ndarray, genes: np.ndarray, coords: np.ndarray, p: np.ndarray, k: int, ce: int, seed: int) -> pd.DataFrame:
    methods = {
        "raw_ICA": METHODS["ICA"],
        "high_purity_ICA": METHODS["high_purity_ICA"],
        "adaptive_purity_ICA": METHODS["adaptive_purity_ICA"],
        "residualized_purity_ICA": METHODS["residualized_purity_ICA"],
    }
    rows = []
    for name, fn in methods.items():
        res = fn(x_cpm, k=k, ce=ce, p_cnv=p, seed=seed)
        scores = res["scores"]
        load = res.get("loadings")
        if load is None or load.shape[0] != x_cpm.shape[1]:
            load = loadings(scores, x_cpm)
        fdr, epi_frac = contamination_fdr(load, genes)
        dep = component_dependence(scores)
        stab = stability(fn, x_cpm, k, ce, p, seed)
        moran = moran_mean(scores, coords)
        # Real-data ranking: stable, non-contaminated, not redundant, spatially coherent.
        overall = max(stab, 1e-6) * max(1 - fdr, 1e-6) * max(1 - dep, 1e-6) * max((moran + 1) / 2, 1e-6)
        overall = overall ** 0.25
        rows.append({
            "method": name,
            "mode": res.get("mode", ""),
            "stability": stab,
            "contam_fdr": fdr,
            "epi_top_frac": epi_frac,
            "dep": dep,
            "moran": moran,
            "real_overall": float(overall),
            **res.get("diagnostics", {}),
        })
    return pd.DataFrame(rows).sort_values("real_overall", ascending=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=DEFAULT_B)
    parser.add_argument("--max-bins", type=int, default=25000)
    parser.add_argument("--max-genes", type=int, default=2500)
    parser.add_argument("--k", type=int, default=6)
    parser.add_argument("--ce", type=int, default=3)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    os.makedirs(OUT, exist_ok=True)

    print(f"[load] {args.base}", flush=True)
    x_counts, genes, _, coords = load_10x_dir(args.base, args.max_bins, args.seed)
    x_cpm_all = cpm(x_counts)
    p, diag = purity_proxy(x_cpm_all, genes)
    hvg = top_hvg(x_cpm_all, args.max_genes)
    x_cpm = x_cpm_all[:, hvg]
    genes_hvg = genes[hvg]
    print(f"[data] bins={x_cpm.shape[0]} genes={x_cpm.shape[1]} p_proxy q50={np.quantile(p,0.5):.3f} q80={np.quantile(p,0.8):.3f}", flush=True)

    rank = run_rank(x_cpm, genes_hvg, coords, p, args.k, args.ce, args.seed)
    out_scores = os.path.join(OUT, "visium_hd_crc_method_ranking.csv")
    out_diag = os.path.join(OUT, "visium_hd_crc_marker_proxy.csv")
    rank.to_csv(out_scores, index=False)
    diag.to_csv(out_diag, index=False)
    print("\n=== Visium HD CRC real-data diagnostic ranking ===")
    print(rank.round(3).to_string(index=False))
    print(f"\n[out] {out_scores}")
    print(f"[out] {out_diag}")
    print("[note] p_i is marker-derived epithelial-vs-TME proxy, not CNV purity.")


if __name__ == "__main__":
    main()
