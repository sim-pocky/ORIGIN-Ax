"""Controlled positive ORIGIN-Ax v1 run."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../cnv_deconv")))
from simulate import SimConfig, make_dataset  # noqa: E402

from core import OriginAxConfig, make_gene_weight_table, rank01
from run_common import run_origin_ax

HERE = Path(__file__).resolve().parent
OUT = HERE / "results_v1" / "controlled_positive"


def main() -> None:
    cfg = SimConfig(seed=11, n=1200, k_mal=3, k_env=3, genes_per_program=35, n_noise_genes=220, dropout=0.10)
    sim = make_dataset(cfg)
    genes = np.array([f"GENE_{i:04d}" for i in range(sim["CPM"].shape[1])], dtype=object)
    target = np.zeros(len(genes))
    tme = np.zeros(len(genes))
    heldout: set[str] = set()
    for block in sim["mal_blocks"]:
        block = np.asarray(block)
        anchor = block[::2]
        eval_idx = block[1::2]
        target[anchor] = 1.0
        heldout.update(genes[eval_idx].astype(str))
        for i in block:
            genes[i] = f"MAL_POS_{i:03d}"
    for block in sim["env_blocks"]:
        block = np.asarray(block)
        tme[block] = 1.0
        for i in block:
            genes[i] = f"TME_POS_{i:03d}"
    # Rebuild heldout names after renaming.
    heldout = {str(genes[i]) for block in sim["mal_blocks"] for i in np.asarray(block)[1::2]}
    gw_table = make_gene_weight_table(genes, target, tme_penalty=tme, source="controlled_positive_anchor_split")
    gw = {
        "target_support": gw_table["target_support"].to_numpy(float),
        "normal_epithelial_penalty": gw_table["normal_epithelial_penalty"].to_numpy(float),
        "tme_penalty": gw_table["tme_penalty"].to_numpy(float),
        "final_weight": gw_table["final_weight"].to_numpy(float),
    }
    rng = np.random.default_rng(110)
    clone = rank01(0.45 * sim["Z_m"][:, 0] + 0.35 * sim["Z_m"][:, 1] + 0.20 * sim["purity"] + 0.10 * rng.standard_normal(sim["CPM"].shape[0]))
    niche = rank01(sim["Z_e"].mean(axis=1))
    fam, summary = run_origin_ax(
        dataset="controlled_positive",
        x=sim["CPM"],
        genes=genes,
        coords=sim["coords"],
        clone=clone,
        niche=niche,
        gene_weights=gw,
        truth_eval_genes=heldout,
        out_dir=OUT,
        config=OriginAxConfig(k=5),
    )
    summary["heldout_truth_axis_recovery"] = summary["n_passed_truth_mal_axis"]
    pd.DataFrame([summary]).to_csv(OUT / "summary.csv", index=False)
    print(pd.DataFrame([summary]).to_string(index=False))
    if summary["n_passed_truth_mal_axis"] < 1:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
