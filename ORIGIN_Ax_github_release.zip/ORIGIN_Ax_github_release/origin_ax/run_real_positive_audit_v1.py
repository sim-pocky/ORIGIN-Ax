"""Audit statistics for the real-positive ORIGIN-Ax experiment.

This script does not affect ORIGIN-Ax scoring or labels. It quantifies whether
the F1 held-out target-gene overlap is larger than expected by chance under the
same Xenium gene-panel background.
"""
from __future__ import annotations

from math import comb
from pathlib import Path

import numpy as np
import pandas as pd

from run_real_positive_v1 import TARGET_CONFIGS


HERE = Path(__file__).resolve().parent
RESULT_DIR = HERE / "results_v1" / "real_positive_xenium_melanoma"


def safe_corr(x: np.ndarray, y: np.ndarray) -> float:
    if np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return 0.0
    r = float(np.corrcoef(x, y)[0, 1])
    return r if np.isfinite(r) else 0.0


def hypergeom_sf(observed: int, population: int, successes: int, draws: int) -> float:
    denom = comb(population, draws)
    total = 0
    for k in range(observed, min(successes, draws) + 1):
        total += comb(successes, k) * comb(population - successes, draws - k)
    return float(total / denom)


def reconstruct_family_top_genes(family_id: str, top_n: int) -> list[str]:
    fam = pd.read_csv(RESULT_DIR / "axis_family_table.csv")
    row = fam.loc[fam["family_id"] == family_id]
    if row.empty:
        raise ValueError(f"missing family {family_id}")
    member_ids = str(row.iloc[0]["member_axes"]).split(";")
    arrays = np.load(RESULT_DIR / "candidate_axis_arrays.npz", allow_pickle=True)
    axis_ids = [str(x) for x in arrays["axis_id"]]
    loadings = arrays["gene_loadings"]
    genes = pd.read_csv(RESULT_DIR / "gene_weight_anchor.csv")["gene"].astype(str).to_numpy()

    member_loadings = []
    for axis_id in member_ids:
        idx = axis_ids.index(axis_id)
        member_loadings.append(loadings[idx].astype(float))
    ref = member_loadings[0]
    aligned = []
    for loading in member_loadings:
        if safe_corr(loading, ref) < 0:
            loading = -loading
        aligned.append(loading)
    consensus = np.mean(np.vstack(aligned), axis=0)
    order = np.argsort(-consensus)
    if consensus[order[0]] <= 0:
        order = np.argsort(-np.abs(consensus))
    return [str(genes[i]) for i in order[:top_n]]


def main() -> None:
    cfg = TARGET_CONFIGS["myeloid_inflammatory"]
    reference_rows = []
    for category, genes in cfg["offtarget_categories"].items():
        for gene in genes:
            reference_rows.append({
                "target_setting": "myeloid_inflammatory",
                "reference_role": "off_target_false_boundary",
                "reference_category": category,
                "gene": gene,
                "pre_specification_role": "plausible_false_boundary_program_for_melanoma",
            })
    for gene in cfg["target_genes"]:
        reference_rows.append({
            "target_setting": "myeloid_inflammatory",
            "reference_role": "target_support_pool",
            "reference_category": "myeloid_inflammatory",
            "gene": gene,
            "pre_specification_role": "target_definition_pool_split_into_anchor_and_heldout",
        })
    pd.DataFrame(reference_rows).drop_duplicates().to_csv(
        RESULT_DIR / "real_positive_reference_gene_sets.csv",
        index=False,
    )

    design = pd.read_csv(RESULT_DIR / "real_positive_design.csv").iloc[0]
    heldout = {g.strip() for g in str(design["heldout_genes"]).split(",") if g.strip()}
    background = set(pd.read_csv(RESULT_DIR / "gene_weight_anchor.csv")["gene"].astype(str))
    heldout = heldout & background
    top_n = 30
    top_genes = reconstruct_family_top_genes("F1", top_n)
    observed = len(set(top_genes) & heldout)
    population = len(background)
    successes = len(heldout)
    p_hyper = hypergeom_sf(observed, population, successes, top_n)

    rng = np.random.default_rng(0)
    background_arr = np.array(sorted(background), dtype=object)
    n_perm = 10000
    perm_hits = np.zeros(n_perm, dtype=int)
    for i in range(n_perm):
        draw = set(rng.choice(background_arr, size=top_n, replace=False))
        perm_hits[i] = len(draw & heldout)
    p_perm = float((np.sum(perm_hits >= observed) + 1) / (n_perm + 1))

    out = pd.DataFrame([{
        "family_id": "F1",
        "top_n": top_n,
        "top_genes": ",".join(top_genes),
        "heldout_genes": ",".join(sorted(heldout)),
        "background_gene_count": population,
        "heldout_gene_count": successes,
        "observed_overlap": observed,
        "expected_random_overlap": top_n * successes / population,
        "hypergeometric_p_value": p_hyper,
        "permutation_p_value": p_perm,
        "n_permutations": n_perm,
        "audit_role": "post_refinement_evidence_audit_not_scoring",
    }])
    out.to_csv(RESULT_DIR / "f1_heldout_overlap_significance.csv", index=False)
    print(out.to_string(index=False))
    print(RESULT_DIR / "f1_heldout_overlap_significance.csv")
    print(RESULT_DIR / "real_positive_reference_gene_sets.csv")


if __name__ == "__main__":
    main()
