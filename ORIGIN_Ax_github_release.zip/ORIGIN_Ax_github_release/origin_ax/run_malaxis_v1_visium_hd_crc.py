"""ORIGIN-Ax v1 malignant-axis implementation on sampled Visium HD CRC."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../cnv_deconv")))
from visium_hd_crc_rank import cpm, load_10x_dir, top_hvg  # noqa: E402

from core import EPI, OriginAxConfig, gene_weight_arrays_from_table, local_niche_score, marker_clone_proxy  # noqa: E402
from run_common import run_origin_ax

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
DEFAULT_B = ROOT / "data/visium_hd_crc/binned_outputs/square_008um"
OUT = HERE / "results_v1" / "visium_hd_crc"
AXIS5_LIKE = {
    "TSPAN1", "CA4", "SLC26A3", "CLCA4", "DUOX2", "KRT20", "SELENOP", "GUCA2A",
    "GUCA2B", "PHGR1", "CEACAM7", "ITM2C", "PIGR", "FCGBP", "MUC2", "CLCA1", "TFF3", "REG4",
}


def read_clone_anchor(
    path: str,
    barcodes: np.ndarray,
    marker_proxy: np.ndarray,
    min_confidence: float = 0.50,
    min_confident_fraction: float = 0.50,
) -> tuple[np.ndarray, str, bool, str]:
    df = pd.read_csv(path)
    if "bin_id" not in df.columns:
        raise KeyError(f"{path} must contain bin_id")
    aligned = df.drop_duplicates("bin_id").set_index("bin_id").loc[barcodes]
    cnv_cols = [c for c in aligned.columns if str(c).startswith("cnv_")]
    if not cnv_cols:
        cnv_cols = [c for c in aligned.columns if c != "clone_confidence" and pd.api.types.is_numeric_dtype(aligned[c])]
    mat = np.nan_to_num(aligned[cnv_cols].to_numpy(float))
    if mat.shape[1] > 3:
        latent = PCA(n_components=3, random_state=0).fit_transform((mat - mat.mean(0)) / (mat.std(0) + 1e-9))
    else:
        latent = mat
    clone = latent[:, 0].astype(float)
    if np.corrcoef(clone, marker_proxy)[0, 1] < 0:
        clone = -clone
    clone = pd.Series(clone).rank(method="average").to_numpy()
    clone = (clone - 1) / max(1, len(clone) - 1)
    if "clone_confidence" in aligned.columns:
        conf = aligned["clone_confidence"].to_numpy(float)
        mean_conf = float(np.nanmean(conf))
        frac_conf = float(np.mean(conf >= min_confidence))
        ok = mean_conf >= min_confidence and frac_conf >= min_confident_fraction
        summary = f"provided mean={mean_conf:.3f} frac_ge_{min_confidence:.2f}={frac_conf:.3f} pass={ok}"
    else:
        ok = True
        summary = "not_provided_assumed_valid"
    return clone, "cnv", ok, summary


def read_gene_weight_anchor(path: str, genes: np.ndarray) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = ["gene", "malignant_support", "normal_epithelial_penalty", "tme_penalty", "final_weight", "source"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"{path} missing required columns: {missing}")
    df = df[required].copy()
    df["gene"] = df["gene"].astype(str)
    for col in ["malignant_support", "normal_epithelial_penalty", "tme_penalty", "final_weight"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    return df


def _top_set(s: str) -> set[str]:
    return {g.strip() for g in str(s).split(",") if g.strip()}


def baseline_audit(fam: pd.DataFrame, candidates: pd.DataFrame) -> pd.DataFrame:
    axis5_candidate_ids = set()
    axis5_candidate_top = ""
    for c in candidates.itertuples(index=False):
        top_c = _top_set(c.top_genes)
        if len(top_c & AXIS5_LIKE) >= 4:
            axis5_candidate_ids.add(str(c.axis_id))
            if not axis5_candidate_top:
                axis5_candidate_top = str(c.top_genes)
    rows = []
    for r in fam.itertuples(index=False):
        member_ids = set(str(r.member_axes).split(";"))
        is_axis5_family = bool(member_ids & axis5_candidate_ids)
        top_genes_str = axis5_candidate_top if is_axis5_family else r.consensus_top_genes
        top = _top_set(top_genes_str)
        epithelial_hits = sorted(top & (EPI | AXIS5_LIKE))
        epithelial_rule = len(epithelial_hits) >= 3
        cnv_rule = float(r.anchor_alignment) >= 0.10
        high_cnv_rule = float(r.anchor_alignment) >= 0.10 and float(r.identifiability_score) >= 0.50
        naive = epithelial_rule or cnv_rule or high_cnv_rule
        overcall_prevented = bool(naive and r.final_call != "target_axis")
        program_label = "axis5_like" if is_axis5_family or len(top & AXIS5_LIKE) >= 4 else str(r.family_id)
        rows.append({
            "dataset": "visium_hd_crc",
            "program_label": program_label,
            "top_genes": top_genes_str,
            "epithelial_marker_rule": epithelial_rule,
            "cnv_association_rule": cnv_rule,
            "high_cnv_presence_rule": high_cnv_rule,
            "naive_malignant_like_call": naive,
            "v1_family_label": r.family_label,
            "v1_final_call": r.final_call,
            "overcall_prevented": overcall_prevented,
        })
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default=str(DEFAULT_B))
    parser.add_argument("--max-bins", type=int, default=2500)
    parser.add_argument("--max-genes", type=int, default=800)
    parser.add_argument("--k", type=int, default=8)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--clone-csv", default="experiments/malignant_axes/malaxis_oa/results/cnv_anchor.csv")
    parser.add_argument("--gene-weight-csv", default="experiments/malignant_axes/malaxis_oa/results/gene_weight_anchor.csv")
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    x_counts, genes, barcodes, coords = load_10x_dir(args.base, args.max_bins, args.seed)
    x_cpm_all = cpm(x_counts)
    clone_proxy, anchor_diag = marker_clone_proxy(x_cpm_all, genes)
    clone_external, clone_source, confidence_ok, confidence_summary = read_clone_anchor(
        args.clone_csv,
        barcodes,
        clone_proxy,
        0.50,
        0.50,
    )
    clone = clone_external if clone_external is not None else clone_proxy
    attribution_valid = clone_source == "cnv" and confidence_ok
    niche = local_niche_score(anchor_diag["niche_marker_proxy"].to_numpy(), coords)
    hvg = top_hvg(x_cpm_all, args.max_genes)
    x = x_cpm_all[:, hvg]
    genes_hvg = genes[hvg]
    gw_table = read_gene_weight_anchor(args.gene_weight_csv, genes_hvg)
    gw = gene_weight_arrays_from_table(gw_table.rename(columns={"malignant_support": "target_support"}), genes_hvg)
    fam, summary = run_origin_ax(
        dataset="visium_hd_crc",
        x=x,
        genes=genes_hvg,
        coords=coords,
        clone=clone,
        niche=niche,
        gene_weights=gw,
        out_dir=OUT,
        attribution_valid=attribution_valid,
        config=OriginAxConfig(k=args.k),
    )
    cand = pd.read_csv(OUT / "candidate_axis_table.csv")
    audit = baseline_audit(fam, cand)
    audit.to_csv(OUT / "baseline_overcall_audit.csv", index=False)
    axis5 = audit.loc[audit["program_label"] == "axis5_like"]
    axis5_label = axis5["v1_family_label"].iloc[0] if not axis5.empty else "missing"
    naive_fpr = float(audit["overcall_prevented"].mean()) if len(audit) else 0.0
    v1_fpr = float((fam["final_call"] == "target_axis").mean()) if len(fam) else 0.0
    summary.update({
        "clone_source": clone_source,
        "cnv_confidence_summary": confidence_summary,
        "n_off_target_families": int((fam["final_call"] == "off_target_axis").sum()),
        "axis5_like_v1_family_label": axis5_label,
        "naive_raw_ica_false_positive_rate": naive_fpr,
        "v1_false_positive_rate": v1_fpr,
        "has_target_origin_supported_but_attribution_unresolved": bool((fam["family_label"] == "target_origin_supported_but_attribution_unresolved").any()),
    })
    pd.DataFrame([summary]).to_csv(OUT / "summary.csv", index=False)
    print(pd.DataFrame([summary]).to_string(index=False))
    print(audit.to_string(index=False))


if __name__ == "__main__":
    main()
