"""Realistic-enough pseudo-ST simulator for malignant-state decontamination.

The goal is not to make a pretty synthetic world where the method trivially wins.
It generates explicit failure modes:
  - low/mid purity bins where TME programs dominate raw factorization,
  - CNV purity noise that can be random or state-correlated,
  - malignant/TME shared programs such as EMT-vs-CAF-like overlap,
  - optional sharp spatial boundaries that punish over-smoothing.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.neighbors import NearestNeighbors


@dataclass(frozen=True)
class SimConfig:
    seed: int = 0
    n: int = 1800
    k_mal: int = 3
    k_env: int = 3
    genes_per_program: int = 35
    n_noise_genes: int = 260
    depth: int = 3000
    dropout: float = 0.25
    purity_a: float = 2.0
    purity_b: float = 2.0
    cnv_noise: float = 0.10
    cnv_bias: float = 0.0
    cnv_state_coupling: float = 0.0
    shared_program_strength: float = 0.0
    sharp_boundary: bool = False
    spatial_smooth_steps: int = 8


def _zscore(x: np.ndarray) -> np.ndarray:
    return (x - x.mean(axis=0)) / (x.std(axis=0) + 1e-9)


def _smooth_field(z: np.ndarray, nbr_idx: np.ndarray, steps: int) -> np.ndarray:
    out = z.copy()
    for _ in range(steps):
        out = 0.55 * out + 0.45 * out[nbr_idx[:, 1:]].mean(axis=1)
    return _zscore(out)


def make_dataset(cfg: SimConfig) -> dict:
    rng = np.random.default_rng(cfg.seed)
    n = cfg.n
    k_m, k_e = cfg.k_mal, cfg.k_env
    g_prog = cfg.genes_per_program
    g = (k_m + k_e) * g_prog + cfg.n_noise_genes

    coords = rng.uniform(0, 1, size=(n, 2))
    nn = NearestNeighbors(n_neighbors=9).fit(coords)
    _, idx = nn.kneighbors(coords)
    nbr = [row[1:] for row in idx]

    z_m = _smooth_field(rng.standard_normal((n, k_m)), idx, cfg.spatial_smooth_steps)
    z_e = _smooth_field(rng.standard_normal((n, k_e)), idx, cfg.spatial_smooth_steps)
    if cfg.sharp_boundary:
        z_m[:, 0] = np.where(coords[:, 0] > 0.52, 1.0, -1.0) + 0.15 * rng.standard_normal(n)
        z_m = _zscore(z_m)

    purity = rng.beta(cfg.purity_a, cfg.purity_b, size=n)

    w_m = np.zeros((g, k_m))
    w_e = np.zeros((g, k_e))
    mal_blocks, env_blocks = [], []
    for k in range(k_m):
        block = np.arange(k * g_prog, (k + 1) * g_prog)
        mal_blocks.append(block)
        w_m[block, k] = rng.uniform(0.7, 1.4, size=g_prog)
    offset = k_m * g_prog
    for k in range(k_e):
        block = np.arange(offset + k * g_prog, offset + (k + 1) * g_prog)
        env_blocks.append(block)
        w_e[block, k] = rng.uniform(0.7, 1.4, size=g_prog)

    if cfg.shared_program_strength > 0 and k_m and k_e:
        # CAF-like contamination shares part of the EMT-like malignant block.
        shared = mal_blocks[0][: max(5, g_prog // 3)]
        w_e[shared, 0] += cfg.shared_program_strength * rng.uniform(0.6, 1.2, size=len(shared))

    base_m = rng.normal(-0.2, 0.25, size=g)
    base_e = rng.normal(-0.2, 0.25, size=g)
    mal_rate = np.exp(base_m[None, :] + z_m @ w_m.T)
    env_rate = np.exp(base_e[None, :] + z_e @ w_e.T)
    rate = purity[:, None] * mal_rate + (1 - purity)[:, None] * env_rate
    rate = rate / rate.sum(axis=1, keepdims=True) * cfg.depth
    counts = rng.poisson(rate).astype(float)
    if cfg.dropout:
        counts[rng.random(counts.shape) < cfg.dropout] = 0

    lib = counts.sum(axis=1, keepdims=True)
    lib[lib == 0] = 1
    cpm = counts / lib * 1e4
    x = np.log1p(cpm)

    p_cnv = purity + cfg.cnv_bias + rng.normal(0, cfg.cnv_noise, size=n)
    if cfg.cnv_state_coupling:
        p_cnv += cfg.cnv_state_coupling * z_m[:, 0]
    p_cnv = np.clip(p_cnv, 0, 1)

    return {
        "X": x,
        "CPM": cpm,
        "counts": counts,
        "coords": coords,
        "nbr": nbr,
        "purity": purity,
        "p_cnv": p_cnv,
        "Z_m": z_m,
        "Z_e": z_e,
        "U_m": w_m,
        "U_e": w_e,
        "mal_blocks": mal_blocks,
        "env_blocks": env_blocks,
        "config": cfg,
    }


PRESETS = {
    "baseline": SimConfig(seed=0),
    "high_contam": SimConfig(seed=1, purity_a=1.2, purity_b=3.0),
    "cnv_noisy": SimConfig(seed=2, cnv_noise=0.25),
    "cnv_state_bias": SimConfig(seed=3, cnv_noise=0.12, cnv_state_coupling=-0.12),
    "shared_emt_caf": SimConfig(seed=4, shared_program_strength=1.3),
    "sharp_boundary": SimConfig(seed=5, sharp_boundary=True),
}
