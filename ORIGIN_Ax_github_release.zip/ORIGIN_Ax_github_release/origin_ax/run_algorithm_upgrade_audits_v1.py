"""Minimal audits for origin-constrained graph refinement.

These audits support the algorithmic upgrade from expression-only family
clustering to origin-constrained graph refinement. They do not add new
decomposition methods or tune score thresholds.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../cnv_deconv")))
from simulate import SimConfig, make_dataset  # noqa: E402

from axis_family import build_axis_families, origin_graph_edges
from candidate_generation import generate_candidates
from core import OriginAxConfig, global_gate_summary, make_gene_weight_table, rank01
from run_real_positive_v1 import apply_target_specific_offtarget_report, build_real_neighborhoods
from scoring import score_families


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results_v1"


def _metrics(fam: pd.DataFrame, truth_min: int) -> dict[str, int]:
    if fam.empty:
        return {"target_calls": 0, "truth_hits": 0, "false_target_calls": 0}
    is_target = fam["final_call"].eq("target_axis")
    truth = fam.get("heldout_truth_overlap", 0) >= truth_min
    return {
        "target_calls": int(is_target.sum()),
        "truth_hits": int((is_target & truth).sum()),
        "false_target_calls": int((is_target & ~truth).sum()),
    }


def _controlled_data() -> dict:
    cfg = SimConfig(seed=11, n=1200, k_mal=3, k_env=3, genes_per_program=35, n_noise_genes=220, dropout=0.10)
    sim = make_dataset(cfg)
    genes = np.array([f"GENE_{i:04d}" for i in range(sim["CPM"].shape[1])], dtype=object)
    target = np.zeros(len(genes))
    tme = np.zeros(len(genes))
    for block in sim["mal_blocks"]:
        block = np.asarray(block)
        target[block[::2]] = 1.0
        for i in block:
            genes[i] = f"MAL_POS_{i:03d}"
    for block in sim["env_blocks"]:
        block = np.asarray(block)
        tme[block] = 1.0
        for i in block:
            genes[i] = f"TME_POS_{i:03d}"
    heldout = {str(genes[i]) for block in sim["mal_blocks"] for i in np.asarray(block)[1::2]}
    gw_table = make_gene_weight_table(genes, target, tme_penalty=tme, source="controlled_positive_anchor_split")
    gw = {
        "target_support": gw_table["target_support"].to_numpy(float),
        "normal_epithelial_penalty": gw_table["normal_epithelial_penalty"].to_numpy(float),
        "tme_penalty": gw_table["tme_penalty"].to_numpy(float),
        "final_weight": gw_table["final_weight"].to_numpy(float),
    }
    rng = np.random.default_rng(110)
    clone = rank01(0.45 * sim["Z_m"][:, 0] + 0.35 * sim["Z_m"][:, 1] + 0.20 * sim["purity"] + 0.10 * rng.standard_normal(sim["CPM"].shape[0]))
    niche = rank01(sim["Z_e"].mean(axis=1))
    return {"x": sim["CPM"], "genes": genes, "coords": sim["coords"], "clone": clone, "niche": niche, "gw": gw, "truth": heldout}


def _score_variant(dat: dict, variant: str) -> pd.DataFrame:
    config = OriginAxConfig(k=5)
    candidates, _ = generate_candidates(dat["x"], dat["genes"], dat["gw"], k=config.k, seeds=config.seeds)
    use_origin = variant != "expression_only_graph"
    families, _ = build_axis_families(
        candidates,
        dat["genes"],
        similarity_threshold=config.similarity_threshold,
        gene_weights=dat["gw"],
        origin_graph_enabled=use_origin,
        origin_compatibility_weight=config.origin_compatibility_weight,
        origin_conflict_penalty=config.origin_conflict_penalty,
    )
    gates = global_gate_summary(dat["clone"], dat["niche"], dat["coords"], attribution_valid=True)
    fam, _ = score_families(families, dat["genes"], dat["gw"], dat["clone"], dat["niche"], gates, truth_eval_genes=dat["truth"])
    if variant == "origin_graph_without_margin":
        calls = pd.Series("not_target_axis", index=fam.index)
        calls.loc[fam["origin_core_score"] > 0.20] = "target_axis"
        calls.loc[fam["origin_core_score"] < -0.20] = "off_target_axis"
        fam = fam.copy()
        fam["final_call"] = calls
    return fam


def graph_refinement_ablation() -> pd.DataFrame:
    dat = _controlled_data()
    config = OriginAxConfig(k=5)
    candidates, _ = generate_candidates(dat["x"], dat["genes"], dat["gw"], k=config.k, seeds=config.seeds)
    edges = origin_graph_edges(
        candidates,
        dat["gw"],
        similarity_threshold=config.similarity_threshold,
        origin_compatibility_weight=config.origin_compatibility_weight,
        origin_conflict_penalty=config.origin_conflict_penalty,
    )
    rows = []
    for variant in ["expression_only_graph", "origin_graph_without_margin", "origin_graph_with_margin"]:
        fam = _score_variant(dat, variant)
        m = _metrics(fam, truth_min=4)
        rows.append({
            "dataset": "controlled_positive",
            "variant": variant,
            "n_axis_families": int(len(fam)),
            "expression_edges": int(edges["expression_edge"].sum()),
            "origin_constrained_edges": int(edges["origin_constrained_edge"].sum()),
            "cross_origin_edges_after_refinement": int(((edges["origin_i"] != edges["origin_j"]) & edges["origin_constrained_edge"]).sum()),
            **m,
            "conclusion": "origin evidence changes family construction and removes cross-origin bridge edges",
        })
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "origin_graph_refinement_ablation.csv", index=False)
    return out


def reference_robustness() -> pd.DataFrame:
    class Args:
        path = "data/tumor_st/xenium_melanoma/processed.h5ad"
        label_key = "cell_type"
        target = "myeloid_inflammatory"
        target_cell_types = None
        n_neighborhoods = 900
        neighbor_cells = 35
        axis_k = 6
        seed = 7

    dat = build_real_neighborhoods(Args())
    config = OriginAxConfig(k=Args.axis_k)
    candidates, _ = generate_candidates(dat["x"], dat["genes"], dat["gene_weights"], k=config.k, seeds=config.seeds)
    penalty_idx = np.where((dat["gene_weights"]["normal_epithelial_penalty"] + dat["gene_weights"]["tme_penalty"]) > 0)[0]
    rng = np.random.default_rng(123)
    rows = []
    for frac in [0.0, 0.2, 0.4, 0.6]:
        gw = {k: np.array(v, copy=True) for k, v in dat["gene_weights"].items()}
        if frac > 0 and len(penalty_idx) > 0:
            drop = rng.choice(penalty_idx, size=int(round(frac * len(penalty_idx))), replace=False)
            gw["normal_epithelial_penalty"][drop] = 0.0
            gw["tme_penalty"][drop] = 0.0
            gw["final_weight"] = gw["target_support"] - gw["normal_epithelial_penalty"] - gw["tme_penalty"]
        families, _ = build_axis_families(
            candidates,
            dat["genes"],
            similarity_threshold=config.similarity_threshold,
            gene_weights=gw,
            origin_graph_enabled=True,
            origin_compatibility_weight=config.origin_compatibility_weight,
            origin_conflict_penalty=config.origin_conflict_penalty,
        )
        gates = global_gate_summary(dat["clone"], dat["niche"], dat["coords"], attribution_valid=True)
        fam, _ = score_families(families, dat["genes"], gw, dat["clone"], dat["niche"], gates, truth_eval_genes=dat["truth_eval_genes"])
        report = apply_target_specific_offtarget_report(fam, dat["offtarget_categories"], dat["anchor_genes"])
        strict = (report["final_call"].eq("target_axis") & (report["heldout_truth_overlap"] >= 2))
        forbidden_rejected = report.get("max_offtarget_source", pd.Series("", index=report.index)).isin({"stromal", "fibroblast", "ECM", "endothelial", "malignant_melanoma"}) & report["final_call"].eq("not_target_axis")
        rows.append({
            "dataset": "real_positive_xenium_myeloid",
            "dropped_offtarget_reference_fraction": frac,
            "n_axis_families": int(len(report)),
            "n_strict_positive_families": int(strict.sum()),
            "n_forbidden_offtarget_rejected": int(forbidden_rejected.sum()),
            "target_recovery_stable": bool(strict.sum() >= 1),
            "offtarget_rejection_stable": bool(forbidden_rejected.sum() >= 1),
        })
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "reference_robustness_summary.csv", index=False)
    return out


def _random_margin_pvalue(gw_table: pd.DataFrame, top_genes: list[str], n_perm: int = 10000, seed: int = 19) -> dict:
    by_gene = gw_table.drop_duplicates("gene").set_index("gene")
    genes = by_gene.index.astype(str).to_numpy()
    target = by_gene.get("target_support", by_gene.get("malignant_support", pd.Series(0.0, index=by_gene.index))).to_numpy(float)
    normal = by_gene.get("normal_epithelial_penalty", pd.Series(0.0, index=by_gene.index)).to_numpy(float)
    tme = by_gene.get("tme_penalty", pd.Series(0.0, index=by_gene.index)).to_numpy(float)
    gene_to_idx = {g: i for i, g in enumerate(genes)}
    idx = [gene_to_idx[g] for g in top_genes if g in gene_to_idx]
    if not idx:
        return {"observed_margin": 0.0, "empirical_p_ge_observed": 1.0, "n_top_genes_used": 0}
    def margin(ii: list[int] | np.ndarray) -> float:
        return float(np.mean(target[ii]) - max(np.mean(normal[ii]), np.mean(tme[ii]), 0.0))
    observed = margin(idx)
    rng = np.random.default_rng(seed)
    null = np.array([margin(rng.choice(len(genes), size=len(idx), replace=False)) for _ in range(n_perm)])
    p = float((np.sum(null >= observed) + 1) / (len(null) + 1))
    return {
        "observed_margin": observed,
        "null_mean_margin": float(np.mean(null)),
        "null_sd_margin": float(np.std(null)),
        "empirical_p_ge_observed": p,
        "n_top_genes_used": int(len(idx)),
    }


def null_calibration() -> pd.DataFrame:
    rows = []
    real_fam = pd.read_csv(RESULTS / "real_positive_xenium_melanoma" / "axis_family_table.csv")
    real_design = pd.read_csv(RESULTS / "real_positive_xenium_melanoma" / "real_positive_design.csv")
    real_gw = pd.read_csv(RESULTS / "real_positive_xenium_melanoma" / "gene_weight_anchor.csv")
    main_family = real_fam.loc[real_fam["final_call"].eq("target_axis")].iloc[0]
    top = [g.strip() for g in str(main_family["top_genes"]).split(",") if g.strip()]
    rows.append({
        "dataset": "real_positive_xenium_myeloid",
        "family_id": main_family["family_id"],
        "final_call": main_family["final_call"],
        "audit": "random_gene_set_margin_null",
        **_random_margin_pvalue(real_gw, top),
    })
    crc_fam = pd.read_csv(RESULTS / "visium_hd_crc" / "baseline_overcall_audit.csv")
    crc_gw = pd.read_csv("experiments/malignant_axes/malaxis_oa/results/gene_weight_anchor.csv")
    axis5 = crc_fam.loc[crc_fam["program_label"].eq("axis5_like")].iloc[0]
    top = [g.strip() for g in str(axis5["top_genes"]).split(",") if g.strip()]
    rows.append({
        "dataset": "visium_hd_crc_stress",
        "family_id": axis5["program_label"],
        "final_call": axis5["v1_final_call"],
        "audit": "random_gene_set_margin_null",
        **_random_margin_pvalue(crc_gw, top),
    })
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "null_calibration_summary.csv", index=False)
    return out


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    graph = graph_refinement_ablation()
    robust = reference_robustness()
    null = null_calibration()
    print(graph.to_string(index=False))
    print(robust.to_string(index=False))
    print(null.to_string(index=False))


if __name__ == "__main__":
    main()
