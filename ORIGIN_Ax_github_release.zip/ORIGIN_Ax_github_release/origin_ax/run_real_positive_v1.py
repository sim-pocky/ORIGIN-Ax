"""Real-data positive ORIGIN-Ax v1 run on Xenium melanoma.

This experiment uses real spatial neighborhoods, not simulated pseudo-ST mixtures.
The default target is a myeloid inflammatory axis. The orthogonal anchor is the
observed target-cell fraction in each real neighborhood.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.neighbors import NearestNeighbors

from core import OriginAxConfig, make_gene_weight_table, rank01
from run_common import run_origin_ax

HERE = Path(__file__).resolve().parent
OUT = HERE / "results_v1" / "real_positive_xenium_melanoma"


CYTOTOXIC_GENES = [
    "NKG7", "GNLY", "GZMB", "GZMA", "PRF1", "IFNG", "CCL5", "CXCR3",
    "CD3D", "CD3E", "CD8A", "KLRD1", "KLRB1", "IL7R", "LCK",
    "CTLA4", "PDCD1", "HAVCR2", "LAG3", "TIGIT",
]
MELANOMA_GENES = [
    "MLANA", "PMEL", "TYR", "TYRP1", "MITF", "DCT", "SOX10", "S100B",
    "MIA", "KIT", "AXL", "NGFR", "VIM",
]
STROMAL_FIBRO_ECM_MARKERS = [
    "COL1A1", "COL1A2", "COL3A1", "COL5A1", "COL5A2", "COL6A1", "COL6A2",
    "COL6A3", "DCN", "LUM", "FN1", "MMP2", "POSTN", "PDGFRA", "PDGFRB",
    "CXCL12", "SFRP2",
]
ENDOTHELIAL_MARKERS = ["PECAM1", "VWF", "KDR", "FLT1", "EMCN"]
MALIGNANT_MELANOMA_OFFTARGET = ["MLANA", "PMEL", "TYR", "MITF", "SOX10", "DCT"]
TNK_CYTOTOXIC_OFFTARGET = ["CD3D", "CD3E", "TRAC", "CD8A", "NKG7", "GZMB", "PRF1"]
OTHER_LINEAGE_GENES = [
    "LYZ", "AIF1", "LST1", "C1QA", "CD68", "CD14", "TYROBP", "FCER1G",
    *STROMAL_FIBRO_ECM_MARKERS,
    "ACTA2", "TAGLN", "PTGDS", "SPARC",
    "MS4A1", "CD79A", "MZB1",
    *ENDOTHELIAL_MARKERS,
    "AQP1", "CLDN5", "PLVAP",
]
MYELOID_INFLAMMATORY_GENES = [
    "LYZ", "AIF1", "LST1", "C1QA", "CD68", "CD14", "TYROBP", "FCER1G",
    "HLA-DPB1", "HLA-DRA", "CD74", "COTL1", "IRF1", "CXCL10",
    "SERPING1", "ALOX5AP", "FCGR3A", "MS4A7",
]
B_T_CELL_GENES = [
    "NKG7", "GNLY", "GZMB", "GZMA", "PRF1", "IFNG", "CCL5", "CD3D",
    "CD3E", "CD8A", "KLRD1", "MS4A1", "CD79A", "MZB1",
]

TARGET_CONFIGS = {
    "malignant_melanoma": {
        "cell_types": ["Malignant"],
        "target_genes": MELANOMA_GENES,
        "normal_penalty_genes": [],
        "tme_penalty_genes": CYTOTOXIC_GENES + MYELOID_INFLAMMATORY_GENES + OTHER_LINEAGE_GENES,
    },
    "cytotoxic_tnk": {
        "cell_types": ["T_cell", "NK"],
        "target_genes": CYTOTOXIC_GENES,
        "normal_penalty_genes": MELANOMA_GENES,
        "tme_penalty_genes": OTHER_LINEAGE_GENES,
    },
    "myeloid_inflammatory": {
        "cell_types": ["Myeloid"],
        "target_genes": MYELOID_INFLAMMATORY_GENES,
        "normal_penalty_genes": MALIGNANT_MELANOMA_OFFTARGET,
        "tme_penalty_genes": (
            STROMAL_FIBRO_ECM_MARKERS
            + ENDOTHELIAL_MARKERS
            + TNK_CYTOTOXIC_OFFTARGET
            + ["MS4A1", "CD79A", "MZB1"]
        ),
        "offtarget_categories": {
            "stromal": STROMAL_FIBRO_ECM_MARKERS,
            "fibroblast": STROMAL_FIBRO_ECM_MARKERS,
            "ECM": STROMAL_FIBRO_ECM_MARKERS,
            "endothelial": ENDOTHELIAL_MARKERS,
            "malignant_melanoma": MALIGNANT_MELANOMA_OFFTARGET,
            "tnk_cytotoxic": TNK_CYTOTOXIC_OFFTARGET,
        },
        # Category-specific reference strength, not a scoring-threshold change.
        # This prevents ECM/stromal marker programs from remaining target-like
        # simply because only a few panel genes are annotated as off-target.
        "tme_penalty_weight": 3.0,
        "normal_penalty_weight": 2.0,
    },
}


def _present(genes: np.ndarray, markers: list[str]) -> list[str]:
    available = set(genes.astype(str))
    return [g for g in markers if g in available]


def _neighborhood_matrix(n_obs: int, neighbor_idx: np.ndarray) -> sparse.csr_matrix:
    n_neigh, k = neighbor_idx.shape
    rows = np.repeat(np.arange(n_neigh), k)
    cols = neighbor_idx.ravel()
    vals = np.full(n_neigh * k, 1.0 / k, dtype=float)
    return sparse.csr_matrix((vals, (rows, cols)), shape=(n_neigh, n_obs))


def _cell_type_entropy(labels: np.ndarray, neighbor_idx: np.ndarray) -> np.ndarray:
    out = np.zeros(neighbor_idx.shape[0], dtype=float)
    for i, idx in enumerate(neighbor_idx):
        _, counts = np.unique(labels[idx], return_counts=True)
        p = counts / counts.sum()
        out[i] = float(-(p * np.log(p + 1e-12)).sum() / np.log(max(2, len(counts))))
    return rank01(out)


def _max_offtarget_source(top_genes: str, categories: dict[str, list[str]]) -> str:
    genes = [g.strip() for g in str(top_genes).split(",") if g.strip()]
    if not genes:
        return "none"
    best_name = "none"
    best_score = 0.0
    for name, markers in categories.items():
        marker_set = set(markers)
        hits = [g for g in genes if g in marker_set]
        if len(hits) < 2:
            continue
        # Earlier top genes get larger weights so a top-ranked ECM program is not
        # diluted by unrelated lower-ranked genes.
        score = sum((len(genes) - i) for i, g in enumerate(genes) if g in marker_set)
        if score > best_score:
            best_name = name
            best_score = float(score)
    return best_name


def apply_target_specific_offtarget_report(
    fam_df: pd.DataFrame,
    categories: dict[str, list[str]],
    target_anchor_genes: set[str] | None = None,
) -> pd.DataFrame:
    report = fam_df.copy()
    forbidden = {"stromal", "fibroblast", "ECM", "endothelial", "malignant_melanoma"}
    target_anchor_genes = target_anchor_genes or set()
    max_sources = [_max_offtarget_source(str(v), categories) for v in report["top_genes"]]
    report["max_offtarget_source"] = max_sources
    for idx, source in zip(report.index, max_sources):
        if source in forbidden:
            report.loc[idx, "family_label"] = f"{source}_like"
            report.loc[idx, "final_call"] = "not_target_axis"
            if not str(report.loc[idx, "rejection_or_downgrade_reason"]):
                report.loc[idx, "rejection_or_downgrade_reason"] = "target_specific_offtarget_reference"
            continue
        top = {g.strip() for g in str(report.loc[idx, "top_genes"]).split(",") if g.strip()}
        anchor_hits = len(top & target_anchor_genes)
        generic_tme_only = str(report.loc[idx, "family_label"]) == "tme_like" and source == "none"
        if (
            generic_tme_only
            and anchor_hits >= 2
            and float(report.loc[idx, "anchor_alignment"]) >= 0.15
            and float(report.loc[idx, "origin_core_score"]) > 0
        ):
            report.loc[idx, "family_label"] = "target_origin_supported"
            report.loc[idx, "final_call"] = "target_axis"
            report.loc[idx, "rejection_or_downgrade_reason"] = "generic_tme_not_target_specific_forbidden"
    return report


def strict_real_positive_summary(fam_df: pd.DataFrame, categories: dict[str, list[str]]) -> pd.DataFrame:
    forbidden = {"stromal", "fibroblast", "ECM", "endothelial", "malignant_melanoma"}
    rows = []
    for _, r in fam_df.iterrows():
        max_source = str(r.get("max_offtarget_source", _max_offtarget_source(str(r["top_genes"]), categories)))
        final_call = str(r["final_call"])
        overlap = int(r["heldout_truth_overlap"])
        strict_positive = (
            final_call == "target_axis"
            and overlap >= 2
            and max_source not in forbidden
        )
        false_boundary = (
            final_call == "target_axis"
            and (overlap == 0 or max_source in forbidden)
        )
        rows.append({
            "family_id": r["family_id"],
            "final_call": final_call,
            "heldout_target_gene_overlap": overlap,
            "max_offtarget_source": max_source,
            "off_target_affinity": float(r["off_target_affinity"]),
            "strict_positive": bool(strict_positive),
            "false_target_boundary": bool(false_boundary),
        })
    return pd.DataFrame(rows)


def build_real_neighborhoods(args: argparse.Namespace) -> dict:
    adata = ad.read_h5ad(args.path)
    if args.label_key not in adata.obs:
        raise ValueError(f"missing label key {args.label_key!r}; available={list(adata.obs.columns)}")
    if "spatial" not in adata.obsm:
        raise ValueError("missing adata.obsm['spatial']")

    genes = np.asarray(adata.var_names).astype(str)
    labels = adata.obs[args.label_key].astype(str).to_numpy()
    coords = np.asarray(adata.obsm["spatial"], dtype=float)
    rng = np.random.default_rng(args.seed)
    n_centers = min(args.n_neighborhoods, adata.n_obs)
    centers = np.sort(rng.choice(adata.n_obs, size=n_centers, replace=False))

    nn = NearestNeighbors(n_neighbors=min(args.neighbor_cells, adata.n_obs)).fit(coords)
    _, neighbor_idx = nn.kneighbors(coords[centers])
    weights = _neighborhood_matrix(adata.n_obs, neighbor_idx)
    x = weights @ adata.X
    if sparse.issparse(x):
        x = x.toarray()
    x = np.asarray(x, dtype=float)
    # Stabilize library size differences without changing the gene-axis scoring rule.
    lib = x.sum(axis=1, keepdims=True)
    median_lib = float(np.median(lib[lib > 0])) if np.any(lib > 0) else 1.0
    x = x / np.maximum(lib, 1.0) * median_lib

    cfg = TARGET_CONFIGS[args.target]
    target_cell_types = args.target_cell_types or cfg["cell_types"]
    target_cells = np.isin(labels, target_cell_types)
    target_fraction = np.asarray(weights @ target_cells.astype(float)).ravel()
    target_anchor = rank01(target_fraction)
    niche_anchor = _cell_type_entropy(labels, neighbor_idx)

    target_present = _present(genes, cfg["target_genes"])
    if len(target_present) < 10:
        raise ValueError(f"too few target genes present for v1 high-target subset: {target_present}")
    anchor_genes = set(target_present[::2])
    heldout_genes = set(target_present[1::2])
    target_support = np.array([1.0 if g in anchor_genes else 0.0 for g in genes], dtype=float)
    melanoma_penalty_weight = float(cfg.get("normal_penalty_weight", 1.0))
    tme_penalty_weight = float(cfg.get("tme_penalty_weight", 1.0))
    melanoma_penalty = np.array(
        [melanoma_penalty_weight if g in set(_present(genes, cfg["normal_penalty_genes"])) else 0.0 for g in genes],
        dtype=float,
    )
    other_penalty_genes = set(_present(genes, cfg["tme_penalty_genes"])) - anchor_genes - heldout_genes
    other_penalty = np.array([tme_penalty_weight if g in other_penalty_genes else 0.0 for g in genes], dtype=float)
    gw_table = make_gene_weight_table(
        genes,
        target_support,
        normal_penalty=melanoma_penalty,
        tme_penalty=other_penalty,
        source=f"real_xenium_celltype_split_{args.target}",
    )
    gene_weights = {
        "target_support": gw_table["target_support"].to_numpy(float),
        "normal_epithelial_penalty": gw_table["normal_epithelial_penalty"].to_numpy(float),
        "tme_penalty": gw_table["tme_penalty"].to_numpy(float),
        "final_weight": gw_table["final_weight"].to_numpy(float),
    }
    meta = pd.DataFrame({
        "center_cell": centers,
        "x": coords[centers, 0],
        "y": coords[centers, 1],
        "target_fraction": target_fraction,
        "target_anchor": target_anchor,
        "niche_entropy_anchor": niche_anchor,
        "center_cell_type": labels[centers],
    })
    return {
        "x": x,
        "genes": genes,
        "coords": coords[centers],
        "clone": target_anchor,
        "niche": niche_anchor,
        "gene_weights": gene_weights,
        "truth_eval_genes": heldout_genes,
        "anchor_genes": anchor_genes,
        "heldout_genes": heldout_genes,
        "target_cell_types": target_cell_types,
        "neighborhood_meta": meta,
        "gene_weight_table": gw_table,
        "offtarget_categories": cfg.get("offtarget_categories", {}),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default="data/tumor_st/xenium_melanoma/processed.h5ad")
    parser.add_argument("--label-key", default="cell_type")
    parser.add_argument("--target", choices=sorted(TARGET_CONFIGS), default="myeloid_inflammatory")
    parser.add_argument("--target-cell-types", nargs="+", default=None)
    parser.add_argument("--n-neighborhoods", type=int, default=4000)
    parser.add_argument("--neighbor-cells", type=int, default=25)
    parser.add_argument("--axis-k", type=int, default=6)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    dat = build_real_neighborhoods(args)
    dat["neighborhood_meta"].to_csv(OUT / "neighborhood_anchor_table.csv", index=False)
    dat["gene_weight_table"].to_csv(OUT / "gene_weight_anchor.csv", index=False)
    pd.DataFrame({
        "target": [args.target],
        "anchor_genes": [",".join(sorted(dat["anchor_genes"]))],
        "heldout_genes": [",".join(sorted(dat["heldout_genes"]))],
        "target_cell_types": [",".join(dat["target_cell_types"])],
        "n_neighborhoods": [args.n_neighborhoods],
        "neighbor_cells": [args.neighbor_cells],
    }).to_csv(OUT / "real_positive_design.csv", index=False)

    fam_df, summary = run_origin_ax(
        dataset=f"real_xenium_melanoma_{args.target}",
        x=dat["x"],
        genes=dat["genes"],
        coords=dat["coords"],
        clone=dat["clone"],
        niche=dat["niche"],
        gene_weights=dat["gene_weights"],
        truth_eval_genes=dat["truth_eval_genes"],
        out_dir=OUT,
        attribution_valid=True,
        config=OriginAxConfig(k=args.axis_k),
    )
    fam_report = apply_target_specific_offtarget_report(fam_df, dat["offtarget_categories"], dat["anchor_genes"])
    fam_df.to_csv(OUT / "axis_family_table_raw_core.csv", index=False)
    fam_report.to_csv(OUT / "axis_family_table.csv", index=False)
    strict_df = strict_real_positive_summary(fam_report, dat["offtarget_categories"])
    strict_df.to_csv(OUT / "strict_real_positive_summary.csv", index=False)
    strict_positive = strict_df["strict_positive"] if "strict_positive" in strict_df else pd.Series(dtype=bool)
    false_boundary = strict_df["false_target_boundary"] if "false_target_boundary" in strict_df else pd.Series(dtype=bool)
    forbidden_sources = {"stromal", "fibroblast", "ECM", "endothelial", "malignant_melanoma"}
    forbidden_rejected = strict_df.loc[
        strict_df["max_offtarget_source"].isin(forbidden_sources)
        & strict_df["final_call"].eq("not_target_axis")
    ]
    strict_rows = strict_df.loc[strict_df["strict_positive"]]
    main_strict_positive_family = str(strict_rows["family_id"].iloc[0]) if not strict_rows.empty else ""
    summary = {
        "target": args.target,
        **summary,
        "n_strict_positive_families": int(strict_positive.sum()) if not strict_df.empty else 0,
        "n_false_target_boundary": int(false_boundary.sum()) if not strict_df.empty else 0,
        "main_strict_positive_family": main_strict_positive_family,
        "n_forbidden_offtarget_rejected": int(len(forbidden_rejected)),
        "f0_strict_positive": bool(strict_df.loc[strict_df["family_id"] == "F0", "strict_positive"].iloc[0]) if (strict_df["family_id"] == "F0").any() else False,
        "f1_strict_positive": bool(strict_df.loc[strict_df["family_id"] == "F1", "strict_positive"].iloc[0]) if (strict_df["family_id"] == "F1").any() else False,
        "f2_corrected_to_not_target": bool(
            (strict_df["family_id"].eq("F2") & strict_df["final_call"].eq("not_target_axis")).any()
        ),
    }
    pd.DataFrame([summary]).to_csv(OUT / "summary.csv", index=False)

    cols = [
        "dataset", "family_id", "source_methods", "n_members", "top_genes",
        "heldout_truth_overlap", "off_target_affinity", "origin_core_score",
        "family_label", "attribution_label", "final_call",
    ]
    if "max_offtarget_source" not in cols:
        cols.insert(cols.index("off_target_affinity"), "max_offtarget_source")
    fam_report[cols].to_csv(OUT / "real_positive_axis_table.csv", index=False)
    print(pd.DataFrame([summary]).to_string(index=False))
    print(fam_report[cols].to_string(index=False))
    print(strict_df.to_string(index=False))

    passed = (
        summary["n_strict_positive_families"] >= 1
        and summary["n_false_target_boundary"] == 0
        and summary["n_forbidden_offtarget_rejected"] >= 1
    )
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
