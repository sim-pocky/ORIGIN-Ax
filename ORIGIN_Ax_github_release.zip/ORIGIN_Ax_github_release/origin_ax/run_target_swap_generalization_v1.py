"""Minimal target-swap generalization experiment for ORIGIN-Ax v1.

This experiment uses the same Xenium melanoma neighborhood benchmark candidates
under two target definitions:

1. myeloid_inflammatory
2. stromal_fibroblast_ecm

It does not change ORIGIN-Ax scoring, thresholds, clustering, or candidate
generation. The purpose is to show that target definitions can be swapped.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

from axis_family import build_axis_families, origin_graph_edges
from candidate_generation import CandidateAxis, _ica, _nmf, _orient_to_target, candidate_table
from core import OriginAxConfig, global_gate_summary, make_gene_weight_table
from run_real_positive_v1 import (
    CYTOTOXIC_GENES,
    ENDOTHELIAL_MARKERS,
    MALIGNANT_MELANOMA_OFFTARGET,
    MYELOID_INFLAMMATORY_GENES,
    STROMAL_FIBRO_ECM_MARKERS,
    _max_offtarget_source,
    _present,
    build_real_neighborhoods,
)
from scoring import score_families

HERE = Path(__file__).resolve().parent
OUT = HERE / "results_v1"
DETAIL = OUT / "target_swap_generalization"


LYMPHOID_CYTOTOXIC = ["CD3D", "CD3E", "TRAC", "CD8A", "NKG7", "GZMB", "PRF1"]


def _top_genes_from_loading(genes: np.ndarray, loading: np.ndarray, n: int = 30) -> list[str]:
    idx = np.argsort(-loading)[:n]
    if len(idx) == 0 or loading[idx[0]] <= 0:
        idx = np.argsort(-np.abs(loading))[:n]
    return [str(genes[i]) for i in idx]


def target_agnostic_candidates(x: np.ndarray, genes: np.ndarray, k: int) -> list[CandidateAxis]:
    """Generate one shared candidate set; orientation is fixed by absolute loading only."""
    candidates: list[CandidateAxis] = []
    for method, fn, seeds in [
        ("raw_ICA_shared", _ica, (0, 1)),
        ("NMF_shared", _nmf, (0, 1)),
    ]:
        for seed in seeds:
            scores, loadings = fn(x, k, seed)
            for axis_idx in range(k):
                loading = loadings[axis_idx].astype(float)
                score = scores[:, axis_idx].astype(float)
                # Deterministic target-agnostic orientation: largest absolute gene loading is positive.
                max_idx = int(np.argmax(np.abs(loading)))
                if loading[max_idx] < 0:
                    loading = -loading
                    score = -score
                candidates.append(CandidateAxis(
                    axis_id=f"{method}_seed{seed}_axis{axis_idx}",
                    source_method=method,
                    seed=seed,
                    k=k,
                    loading=loading,
                    score=score,
                    top_genes=_top_genes_from_loading(genes, loading, 30),
                    orientation_flipped=False,
                ))
    return candidates


def make_target_weights(
    genes: np.ndarray,
    target_genes: list[str],
    normal_penalty_genes: list[str],
    tme_penalty_genes: list[str],
    source: str,
) -> tuple[dict[str, np.ndarray], set[str], set[str], pd.DataFrame]:
    target_present = _present(genes, target_genes)
    anchor_genes = set(target_present[::2])
    heldout_genes = set(target_present[1::2])
    target = np.array([1.0 if g in anchor_genes else 0.0 for g in genes], dtype=float)
    normal_set = set(_present(genes, normal_penalty_genes)) - anchor_genes - heldout_genes
    tme_set = set(_present(genes, tme_penalty_genes)) - anchor_genes - heldout_genes
    normal = np.array([1.0 if g in normal_set else 0.0 for g in genes], dtype=float)
    tme = np.array([1.0 if g in tme_set else 0.0 for g in genes], dtype=float)
    table = make_gene_weight_table(genes, target, normal_penalty=normal, tme_penalty=tme, source=source)
    return {
        "target_support": table["target_support"].to_numpy(float),
        "normal_epithelial_penalty": table["normal_epithelial_penalty"].to_numpy(float),
        "tme_penalty": table["tme_penalty"].to_numpy(float),
        "final_weight": table["final_weight"].to_numpy(float),
    }, anchor_genes, heldout_genes, table


def orient_candidates_to_target(candidates: list[CandidateAxis], target_support: np.ndarray, target_name: str) -> list[CandidateAxis]:
    oriented: list[CandidateAxis] = []
    for c in candidates:
        loading, score, flipped = _orient_to_target(c.loading, c.score, target_support)
        oriented.append(CandidateAxis(
            axis_id=c.axis_id,
            source_method=c.source_method,
            seed=c.seed,
            k=c.k,
            loading=loading,
            score=score,
            top_genes=_top_genes_from_loading(np.array([], dtype=str), loading, 0) if False else c.top_genes,
            orientation_flipped=bool(c.orientation_flipped or flipped),
        ))
    return oriented


def refresh_top_genes(candidates: list[CandidateAxis], genes: np.ndarray) -> list[CandidateAxis]:
    out: list[CandidateAxis] = []
    for c in candidates:
        out.append(CandidateAxis(
            axis_id=c.axis_id,
            source_method=c.source_method,
            seed=c.seed,
            k=c.k,
            loading=c.loading,
            score=c.score,
            top_genes=_top_genes_from_loading(genes, c.loading, 30),
            orientation_flipped=c.orientation_flipped,
        ))
    return out


def apply_target_specific_report(
    fam_df: pd.DataFrame,
    categories: dict[str, list[str]],
    forbidden_sources: set[str],
) -> pd.DataFrame:
    report = fam_df.copy()
    sources = []
    for top in report["top_genes"]:
        source = _max_offtarget_source(str(top), categories)
        sources.append(source)
    report["max_offtarget_source"] = sources
    for idx, source in zip(report.index, sources):
        if source in forbidden_sources:
            report.loc[idx, "family_label"] = f"{source}_like"
            report.loc[idx, "final_call"] = "not_target_axis"
            report.loc[idx, "rejection_or_downgrade_reason"] = "target_swap_offtarget_reference"
    return report


def run_refinement(
    *,
    target_name: str,
    shared_candidates: list[CandidateAxis],
    genes: np.ndarray,
    coords: np.ndarray,
    clone: np.ndarray,
    niche: np.ndarray,
    gene_weights: dict[str, np.ndarray],
    truth_eval_genes: set[str],
    categories: dict[str, list[str]],
    forbidden_sources: set[str],
) -> pd.DataFrame:
    out_dir = DETAIL / target_name
    out_dir.mkdir(parents=True, exist_ok=True)
    candidates = refresh_top_genes(orient_candidates_to_target(shared_candidates, gene_weights["target_support"], target_name), genes)
    candidate_table(candidates).to_csv(out_dir / "candidate_axis_table.csv", index=False)
    config = OriginAxConfig()
    origin_graph_edges(
        candidates,
        gene_weights,
        similarity_threshold=config.similarity_threshold,
        origin_compatibility_weight=config.origin_compatibility_weight,
        origin_conflict_penalty=config.origin_conflict_penalty,
    ).to_csv(out_dir / "candidate_origin_graph_edges.csv", index=False)
    families, sim_df = build_axis_families(
        candidates,
        genes,
        similarity_threshold=config.similarity_threshold,
        gene_weights=gene_weights,
        origin_graph_enabled=config.origin_graph_enabled,
        origin_compatibility_weight=config.origin_compatibility_weight,
        origin_conflict_penalty=config.origin_conflict_penalty,
    )
    sim_df.to_csv(out_dir / "candidate_similarity.csv")
    gates = global_gate_summary(clone, niche, coords, attribution_valid=True)
    fam_df, norm = score_families(
        families,
        genes,
        gene_weights,
        clone,
        niche,
        gates,
        truth_eval_genes=truth_eval_genes,
    )
    fam_df.insert(0, "dataset", f"target_swap_{target_name}")
    fam_df.to_csv(out_dir / "axis_family_table_raw_core.csv", index=False)
    report = apply_target_specific_report(fam_df, categories, forbidden_sources)
    report.to_csv(out_dir / "axis_family_table.csv", index=False)
    norm.to_csv(out_dir / "score_normalization.csv", index=False)
    return report


def best_match_family(report: pd.DataFrame, markers: set[str]) -> pd.Series:
    best_idx = None
    best_hits = -1
    for idx, row in report.iterrows():
        top = {g.strip() for g in str(row["top_genes"]).split(",") if g.strip()}
        hits = len(top & markers)
        if hits > best_hits:
            best_idx = idx
            best_hits = hits
    if best_idx is None:
        raise ValueError("empty report")
    return report.loc[best_idx]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default="data/tumor_st/xenium_melanoma/processed.h5ad")
    parser.add_argument("--n-neighborhoods", type=int, default=4000)
    parser.add_argument("--neighbor-cells", type=int, default=25)
    parser.add_argument("--k", type=int, default=6)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    DETAIL.mkdir(parents=True, exist_ok=True)
    ns = SimpleNamespace(
        path=args.path,
        label_key="cell_type",
        target="myeloid_inflammatory",
        target_cell_types=None,
        n_neighborhoods=args.n_neighborhoods,
        neighbor_cells=args.neighbor_cells,
        seed=args.seed,
    )
    dat = build_real_neighborhoods(ns)
    stromal_ns = SimpleNamespace(
        path=args.path,
        label_key="cell_type",
        target="myeloid_inflammatory",
        target_cell_types=["Fibroblast"],
        n_neighborhoods=args.n_neighborhoods,
        neighbor_cells=args.neighbor_cells,
        seed=args.seed,
    )
    stromal_anchor_dat = build_real_neighborhoods(stromal_ns)
    genes = dat["genes"]
    shared = target_agnostic_candidates(dat["x"], genes, args.k)
    candidate_table(shared).to_csv(DETAIL / "shared_candidate_axis_table.csv", index=False)

    myeloid_weights, _, myeloid_heldout, myeloid_table = make_target_weights(
        genes,
        MYELOID_INFLAMMATORY_GENES,
        MALIGNANT_MELANOMA_OFFTARGET,
        STROMAL_FIBRO_ECM_MARKERS + ENDOTHELIAL_MARKERS + LYMPHOID_CYTOTOXIC,
        "target_swap_myeloid",
    )
    stromal_weights, _, stromal_heldout, stromal_table = make_target_weights(
        genes,
        STROMAL_FIBRO_ECM_MARKERS,
        MALIGNANT_MELANOMA_OFFTARGET,
        MYELOID_INFLAMMATORY_GENES + ENDOTHELIAL_MARKERS + CYTOTOXIC_GENES,
        "target_swap_stromal",
    )
    myeloid_table.to_csv(DETAIL / "gene_weight_myeloid.csv", index=False)
    stromal_table.to_csv(DETAIL / "gene_weight_stromal.csv", index=False)

    myeloid_categories = {
        "stromal": STROMAL_FIBRO_ECM_MARKERS,
        "endothelial": ENDOTHELIAL_MARKERS,
        "malignant_melanoma": MALIGNANT_MELANOMA_OFFTARGET,
        "lymphoid_cytotoxic": LYMPHOID_CYTOTOXIC,
    }
    stromal_categories = {
        "myeloid_inflammatory": MYELOID_INFLAMMATORY_GENES,
        "endothelial": ENDOTHELIAL_MARKERS,
        "malignant_melanoma": MALIGNANT_MELANOMA_OFFTARGET,
        "lymphoid_cytotoxic": LYMPHOID_CYTOTOXIC,
    }
    myeloid_report = run_refinement(
        target_name="myeloid_inflammatory",
        shared_candidates=shared,
        genes=genes,
        coords=dat["coords"],
        clone=stromal_anchor_dat["clone"],
        niche=dat["niche"],
        gene_weights=myeloid_weights,
        truth_eval_genes=myeloid_heldout,
        categories=myeloid_categories,
        forbidden_sources={"stromal", "endothelial", "malignant_melanoma"},
    )
    stromal_report = run_refinement(
        target_name="stromal_fibroblast_ecm",
        shared_candidates=shared,
        genes=genes,
        coords=dat["coords"],
        clone=dat["clone"],
        niche=dat["niche"],
        gene_weights=stromal_weights,
        truth_eval_genes=stromal_heldout,
        categories=stromal_categories,
        forbidden_sources={"myeloid_inflammatory", "endothelial", "malignant_melanoma"},
    )

    f1_like = best_match_family(myeloid_report, set(MYELOID_INFLAMMATORY_GENES))
    f2_like_myeloid = best_match_family(myeloid_report, set(STROMAL_FIBRO_ECM_MARKERS))
    f2_like_stromal = best_match_family(stromal_report, set(STROMAL_FIBRO_ECM_MARKERS))
    f1_like_stromal = best_match_family(stromal_report, set(MYELOID_INFLAMMATORY_GENES))
    rows = [
        {
            "family_id": "myeloid_F1_like",
            "top_genes": f1_like["top_genes"],
            "call_under_myeloid_target": f1_like["final_call"],
            "call_under_stromal_target": f1_like_stromal["final_call"],
            "target_swap_behavior": "myeloid-supported axis is not the stromal strict positive",
            "conclusion": "myeloid F1-like family is target-supported only under the myeloid target definition",
        },
        {
            "family_id": "stromal_F2_like",
            "top_genes": f2_like_stromal["top_genes"],
            "call_under_myeloid_target": f2_like_myeloid["final_call"],
            "call_under_stromal_target": f2_like_stromal["final_call"],
            "target_swap_behavior": "off-target under myeloid target; target-supported under stromal target",
            "conclusion": "the same stromal-like family rejected as off-target under a myeloid target definition is recovered as target-supported under a stromal target definition",
        },
    ]
    summary = pd.DataFrame(rows)
    summary.to_csv(OUT / "target_swap_generalization_summary.csv", index=False)
    md = OUT / "TARGET_SWAP_GENERALIZATION_SUMMARY.md"
    with open(md, "w", encoding="utf-8") as fh:
        fh.write("# Target-Swap Generalization Summary\n\n")
        fh.write("This is not a new benchmark. It is a minimal control showing that ORIGIN-Ax target definitions can be switched while using the same Xenium melanoma neighborhood candidate axes.\n\n")
        fh.write("The target is changed from `myeloid_inflammatory` to `stromal_fibroblast_ecm`. Core scoring, thresholds, clustering, and candidate generation are unchanged.\n\n")
        fh.write("If the stromal F2-like family is rejected as off-target under a myeloid target definition but recovered as target-supported under a stromal target definition, this supports target-agnostic refinement.\n\n")
        fh.write("Do not claim this proves generalization to all cell states or all spatial transcriptomics data.\n\n")
        fh.write("## Summary Table\n\n")
        fh.write(summary.to_csv(index=False))
    print(summary.to_string(index=False))
    print(OUT / "target_swap_generalization_summary.csv")
    print(md)

    f2_ok = str(f2_like_myeloid["final_call"]) != "target_axis" and str(f2_like_stromal["final_call"]) == "target_axis"
    f1_ok = str(f1_like_stromal["final_call"]) != "target_axis"
    if not (f2_ok and f1_ok):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
