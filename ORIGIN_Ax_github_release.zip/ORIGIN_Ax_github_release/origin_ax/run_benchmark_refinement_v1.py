"""Benchmark-candidate refinement experiment for ORIGIN-Ax v1.

This script treats ICA/NMF/cNMF-like outputs as benchmark-generated axes, then
applies only the ORIGIN-Ax refinement steps:

candidate axes -> axis families -> origin scoring -> final calls

It does not change core scoring, thresholds, clustering, or candidate generation
logic used elsewhere, and it does not run full Visium HD CRC.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../cnv_deconv")))
from pseudo_st import make_pseudo_st  # noqa: E402

from axis_family import build_axis_families, origin_graph_edges
from candidate_generation import CandidateAxis, _ica, _nmf, _orient_to_target, candidate_table
from core import OriginAxConfig, gene_weight_arrays_from_table, global_gate_summary, local_niche_score, marker_clone_proxy, rank01, safe_spearman
from run_malaxis_v1_visium_hd_crc import (
    AXIS5_LIKE,
    DEFAULT_B,
    baseline_audit,
    cpm,
    load_10x_dir,
    read_clone_anchor,
    read_gene_weight_anchor,
    top_hvg,
)
from run_real_positive_v1 import (
    apply_target_specific_offtarget_report,
    build_real_neighborhoods,
    strict_real_positive_summary,
)
from scoring import score_families

HERE = Path(__file__).resolve().parent
OUT = HERE / "results_v1"
DETAIL = OUT / "benchmark_refinement"


def _top_set(top_genes: list[str] | str) -> set[str]:
    if isinstance(top_genes, str):
        return {g.strip() for g in top_genes.split(",") if g.strip()}
    return {str(g).strip() for g in top_genes if str(g).strip()}


def _top_genes_from_loading(genes: np.ndarray, loading: np.ndarray, n: int = 30) -> list[str]:
    idx = np.argsort(-loading)[:n]
    if len(idx) == 0 or loading[idx[0]] <= 0:
        idx = np.argsort(-np.abs(loading))[:n]
    return [str(genes[i]) for i in idx]


def make_benchmark_candidates(
    x: np.ndarray,
    genes: np.ndarray,
    gene_weights: dict[str, np.ndarray],
    method: str,
    k: int,
) -> list[CandidateAxis]:
    if method == "raw_ICA_only":
        seeds = (0, 1)
        fn = _ica
        source = "benchmark_raw_ICA"
    elif method == "NMF_only":
        seeds = (0, 1)
        fn = _nmf
        source = "benchmark_NMF"
    elif method == "cNMF_like_repeated_NMF":
        seeds = (0, 1, 2, 3)
        fn = _nmf
        source = "benchmark_cNMF_like"
    else:
        raise ValueError(f"unknown benchmark method: {method}")

    candidates: list[CandidateAxis] = []
    for seed in seeds:
        scores, loadings = fn(x, k, seed)
        for axis_idx in range(k):
            loading, score, flipped = _orient_to_target(
                loadings[axis_idx].astype(float),
                scores[:, axis_idx].astype(float),
                gene_weights["target_support"],
            )
            candidates.append(CandidateAxis(
                axis_id=f"{source}_seed{seed}_axis{axis_idx}",
                source_method=source,
                seed=seed,
                k=k,
                loading=loading,
                score=score,
                top_genes=_top_genes_from_loading(genes, loading, 30),
                orientation_flipped=flipped,
            ))
    return candidates


def refine_candidates(
    *,
    dataset: str,
    method: str,
    candidates: list[CandidateAxis],
    genes: np.ndarray,
    coords: np.ndarray,
    clone: np.ndarray,
    niche: np.ndarray,
    gene_weights: dict[str, np.ndarray],
    truth_eval_genes: set[str] | None,
    attribution_valid: bool,
    similarity_threshold: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    out_dir = DETAIL / dataset / method
    out_dir.mkdir(parents=True, exist_ok=True)
    cand_df = candidate_table(candidates)
    cand_df.insert(0, "dataset", dataset)
    cand_df.to_csv(out_dir / "benchmark_candidate_axis_table.csv", index=False)
    np.savez_compressed(
        out_dir / "benchmark_candidate_axis_arrays.npz",
        axis_id=np.array([c.axis_id for c in candidates], dtype=object),
        source_method=np.array([c.source_method for c in candidates], dtype=object),
        gene_loadings=np.vstack([c.loading for c in candidates]),
        bin_scores=np.vstack([c.score for c in candidates]),
    )
    config = OriginAxConfig()
    origin_graph_edges(
        candidates,
        gene_weights,
        similarity_threshold=similarity_threshold,
        origin_compatibility_weight=config.origin_compatibility_weight,
        origin_conflict_penalty=config.origin_conflict_penalty,
    ).to_csv(out_dir / "benchmark_candidate_origin_graph_edges.csv", index=False)
    families, sim_df = build_axis_families(
        candidates,
        genes,
        similarity_threshold=similarity_threshold,
        gene_weights=gene_weights,
        origin_graph_enabled=config.origin_graph_enabled,
        origin_compatibility_weight=config.origin_compatibility_weight,
        origin_conflict_penalty=config.origin_conflict_penalty,
    )
    sim_df.to_csv(out_dir / "benchmark_candidate_similarity.csv")
    gates = global_gate_summary(clone, niche, coords, attribution_valid=attribution_valid)
    fam_df, norm_df = score_families(
        families,
        genes,
        gene_weights,
        clone,
        niche,
        gates,
        truth_eval_genes=truth_eval_genes,
    )
    fam_df.insert(0, "dataset", dataset)
    fam_df.to_csv(out_dir / "axis_family_table_after_refinement.csv", index=False)
    norm_df.insert(0, "dataset", dataset)
    norm_df.to_csv(out_dir / "score_normalization.csv", index=False)
    pd.DataFrame([{**{"dataset": dataset}, **gates}]).to_csv(out_dir / "global_gate_report.csv", index=False)
    return cand_df, fam_df, norm_df


def candidate_truth_hits(candidates: list[CandidateAxis], truth_eval_genes: set[str], min_hits: int = 4) -> int:
    return int(sum(len(set(c.top_genes[:30]) & truth_eval_genes) >= min_hits for c in candidates))


def candidate_target_like_calls(candidates: list[CandidateAxis], anchor_genes: set[str], min_hits: int = 2) -> int:
    return int(sum(len(set(c.top_genes[:30]) & anchor_genes) >= min_hits for c in candidates))


def axis5_naive_calls(candidates: list[CandidateAxis], clone: np.ndarray) -> tuple[int, bool]:
    n_calls = 0
    axis5_call = False
    epi_like = set(AXIS5_LIKE)
    for c in candidates:
        top = set(c.top_genes[:30])
        marker_rule = len(top & epi_like) >= 4
        cnv_rule = abs(safe_spearman(c.score, clone)) >= 0.10
        naive = bool(marker_rule or cnv_rule)
        n_calls += int(naive)
        axis5_call = bool(axis5_call or (len(top & epi_like) >= 4 and naive))
    return n_calls, axis5_call


CRC_OFFTARGET_CATEGORIES = {
    "normal_epithelial": set(AXIS5_LIKE) | {
        "PIGR", "FCGBP", "CLCA1", "MUC2", "OLFM4", "AGR2", "SPINK4", "TFF3", "REG4", "ITLN1",
    },
    "stromal": {
        "COL1A1", "COL1A2", "COL3A1", "COL4A1", "COL4A2", "COL5A1", "COL6A1", "COL6A2",
        "COL6A3", "MMP2", "LUM", "DCN", "SPARC", "FN1", "AEBP1", "THBS2", "SFRP4",
        "NID1", "LOXL2", "VIM", "IGFBP7", "MCAM", "COL18A1",
    },
    "smooth_muscle": {
        "DES", "TAGLN", "ACTG2", "MYH11", "MYL9", "CNN1", "SYNPO2", "PLN", "TPM2", "ACTA2",
    },
    "immune": {
        "CD74", "LYZ", "CTSB", "IFI30", "PSAP", "C1QC", "MMP12", "C1QA", "CD68", "SRGN", "C1QB", "APOE",
    },
    "endothelial": {
        "AQP1", "VWF", "ACKR1", "MMRN1", "PECAM1", "EMCN", "ENG", "EGFL7", "SLCO2A1", "TEK",
    },
}


def _crc_max_offtarget_source(top: set[str]) -> str:
    best = "none"
    best_hits = 0
    for name, markers in CRC_OFFTARGET_CATEGORIES.items():
        hits = len(top & markers)
        if hits > best_hits:
            best = name
            best_hits = hits
    return best if best_hits >= 2 else "none"


def apply_crc_axis5_offtarget_report(fam_df: pd.DataFrame, candidates: list[CandidateAxis]) -> pd.DataFrame:
    """Target-specific CRC report layer: epithelial/TME programs are not malignant calls."""
    report = fam_df.copy()
    axis5_candidate_ids = {
        c.axis_id for c in candidates
        if len(set(c.top_genes[:30]) & AXIS5_LIKE) >= 4
    }
    for idx, row in report.iterrows():
        member_ids = set(str(row["member_axes"]).split(";"))
        top = _top_set(str(row["top_genes"]))
        is_axis5 = bool(member_ids & axis5_candidate_ids) or len(top & AXIS5_LIKE) >= 4
        source = "normal_epithelial" if is_axis5 else _crc_max_offtarget_source(top)
        if source != "none":
            report.loc[idx, "family_label"] = f"{source}_like"
            report.loc[idx, "final_call"] = "not_target_axis"
            report.loc[idx, "rejection_or_downgrade_reason"] = f"crc_{source}_offtarget_reference"
    return report


def pseudo_st_inputs(args: argparse.Namespace) -> dict:
    sim = make_pseudo_st(
        path=args.pseudo_path,
        label_key="cell_type",
        malignant_label="Malignant",
        n_bins=args.pseudo_bins,
        max_genes=args.pseudo_genes,
        k=3,
        purity_a=2.0,
        purity_b=2.0,
        cnv_noise=0.08,
        seed=args.seed,
    )
    genes = np.asarray(sim["var_names"]).astype(str)
    target = np.zeros(len(genes))
    tme = np.zeros(len(genes))
    heldout: set[str] = set()
    anchor: set[str] = set()
    for block in sim["mal_blocks"]:
        block = np.asarray(block, dtype=int)
        target[block[::2]] = 1.0
        anchor.update(genes[block[::2]].astype(str))
        heldout.update(genes[block[1::2]].astype(str))
    for block in sim["env_blocks"]:
        tme[np.asarray(block, dtype=int)] = 1.0
    gw = {
        "target_support": target,
        "normal_epithelial_penalty": np.zeros(len(genes)),
        "tme_penalty": tme,
        "final_weight": target - tme,
    }
    clone = rank01(sim["Z_m"][:, 0] + 0.25 * sim["p_cnv"])
    niche = rank01(np.mean(sim["CPM"][:, np.concatenate(sim["env_blocks"])], axis=1))
    return {
        "dataset": "benchmark_pseudo_st_positive",
        "x": sim["CPM"],
        "genes": genes,
        "coords": sim["coords"],
        "clone": clone,
        "niche": niche,
        "gene_weights": gw,
        "anchor_genes": anchor,
        "truth_eval_genes": heldout,
        "attribution_valid": True,
        "k": args.pseudo_k,
    }


def real_positive_inputs(args: argparse.Namespace) -> dict:
    ns = SimpleNamespace(
        path=args.real_path,
        label_key="cell_type",
        target="myeloid_inflammatory",
        target_cell_types=None,
        n_neighborhoods=args.real_neighborhoods,
        neighbor_cells=args.real_neighbor_cells,
        seed=args.seed,
    )
    dat = build_real_neighborhoods(ns)
    return {
        "dataset": "benchmark_real_xenium_myeloid",
        "x": dat["x"],
        "genes": dat["genes"],
        "coords": dat["coords"],
        "clone": dat["clone"],
        "niche": dat["niche"],
        "gene_weights": dat["gene_weights"],
        "anchor_genes": dat["anchor_genes"],
        "truth_eval_genes": dat["heldout_genes"],
        "attribution_valid": True,
        "k": args.real_k,
        "offtarget_categories": dat["offtarget_categories"],
    }


def crc_inputs(args: argparse.Namespace) -> dict:
    x_counts, genes, barcodes, coords = load_10x_dir(args.crc_base, args.crc_bins, args.seed)
    x_cpm_all = cpm(x_counts)
    clone_proxy, anchor_diag = marker_clone_proxy(x_cpm_all, genes)
    clone, _, confidence_ok, _ = read_clone_anchor(args.crc_clone_csv, barcodes, clone_proxy, 0.50, 0.50)
    niche = local_niche_score(anchor_diag["niche_marker_proxy"].to_numpy(), coords)
    hvg = top_hvg(x_cpm_all, args.crc_genes)
    x = x_cpm_all[:, hvg]
    genes_hvg = genes[hvg]
    gw_table = read_gene_weight_anchor(args.crc_gene_weight_csv, genes_hvg)
    gw = gene_weight_arrays_from_table(gw_table.rename(columns={"malignant_support": "target_support"}), genes_hvg)
    return {
        "dataset": "benchmark_visium_hd_crc_stress",
        "x": x,
        "genes": genes_hvg,
        "coords": coords,
        "clone": clone,
        "niche": niche,
        "gene_weights": gw,
        "anchor_genes": set(gw_table.loc[gw_table["malignant_support"] > 0, "gene"].astype(str)),
        "truth_eval_genes": set(),
        "attribution_valid": bool(confidence_ok),
        "k": args.crc_k,
    }


def summarize_pseudo(method: str, candidates: list[CandidateAxis], fam_df: pd.DataFrame, inp: dict) -> dict:
    before_hits = candidate_truth_hits(candidates, inp["truth_eval_genes"], 4)
    before_target = candidate_target_like_calls(candidates, inp["anchor_genes"], 2)
    before_false = int(sum(
        (len(set(c.top_genes[:30]) & inp["anchor_genes"]) >= 2)
        and (len(set(c.top_genes[:30]) & inp["truth_eval_genes"]) < 4)
        for c in candidates
    ))
    after_hits = int(((fam_df["final_call"] == "target_axis") & (fam_df["heldout_truth_overlap"] >= 4)).sum())
    after_target = int((fam_df["final_call"] == "target_axis").sum())
    after_false = int(((fam_df["final_call"] == "target_axis") & (fam_df["heldout_truth_overlap"] < 4)).sum())
    return {
        "dataset": "pseudo_ST_positive",
        "benchmark_method": method,
        "n_input_axes": len(candidates),
        "n_axis_families_after_refinement": len(fam_df),
        "benchmark_target_like_calls": before_target,
        "origin_ax_target_calls": after_target,
        "benchmark_false_target_calls": before_false,
        "origin_ax_false_target_calls": after_false,
        "truth_axis_hits_before": before_hits,
        "truth_axis_hits_after": after_hits,
        "strict_positive_found": "",
        "off_target_rejected": "",
        "false_call_reduction": before_false - after_false,
        "conclusion": "truth target recovery is retained after ORIGIN-Ax refinement" if after_hits > 0 else "truth target not recovered after refinement",
    }


def summarize_real(method: str, candidates: list[CandidateAxis], fam_df: pd.DataFrame, inp: dict) -> dict:
    fam_report = apply_target_specific_offtarget_report(fam_df, inp["offtarget_categories"], inp["anchor_genes"])
    strict = strict_real_positive_summary(fam_report, inp["offtarget_categories"])
    out_dir = DETAIL / inp["dataset"] / method
    fam_report.to_csv(out_dir / "axis_family_table_after_target_specific_report.csv", index=False)
    strict.to_csv(out_dir / "strict_real_positive_summary.csv", index=False)
    before_target = candidate_target_like_calls(candidates, inp["anchor_genes"], 2)
    before_false = int(sum(
        len(set(c.top_genes[:30]) & inp["anchor_genes"]) >= 2
        and len(set(c.top_genes[:30]) & inp["truth_eval_genes"]) < 2
        for c in candidates
    ))
    strict_found = bool(strict["strict_positive"].any()) if not strict.empty else False
    f2_like_rejected = bool(((strict["max_offtarget_source"] == "stromal") & (strict["final_call"] == "not_target_axis")).any()) if not strict.empty else False
    after_target = int((fam_report["final_call"] == "target_axis").sum()) if not fam_report.empty else 0
    after_false = int(strict["false_target_boundary"].sum()) if not strict.empty else 0
    off_rejected = int(((fam_report["final_call"] != "target_axis") & (fam_report.get("max_offtarget_source", "") == "stromal")).sum()) if not fam_report.empty else 0
    conclusion = "strict real-positive axis found and stromal off-target family rejected" if strict_found and f2_like_rejected else "real-positive refinement remains incomplete"
    return {
        "dataset": "real_positive_xenium_myeloid",
        "benchmark_method": method,
        "n_input_axes": len(candidates),
        "n_axis_families_after_refinement": len(fam_report),
        "benchmark_target_like_calls": before_target,
        "origin_ax_target_calls": after_target,
        "benchmark_false_target_calls": before_false,
        "origin_ax_false_target_calls": after_false,
        "truth_axis_hits_before": candidate_truth_hits(candidates, inp["truth_eval_genes"], 2),
        "truth_axis_hits_after": int(strict["strict_positive"].sum()) if not strict.empty else 0,
        "strict_positive_found": strict_found,
        "off_target_rejected": f2_like_rejected,
        "false_call_reduction": before_false - after_false,
        "conclusion": conclusion,
    }


def summarize_crc(method: str, candidates: list[CandidateAxis], fam_df: pd.DataFrame, cand_df: pd.DataFrame, inp: dict) -> dict:
    fam_report = apply_crc_axis5_offtarget_report(fam_df, candidates)
    out_dir = DETAIL / inp["dataset"] / method
    fam_df.to_csv(out_dir / "axis_family_table_after_refinement_raw_core.csv", index=False)
    fam_report.to_csv(out_dir / "axis_family_table_after_crc_axis5_report.csv", index=False)
    audit = baseline_audit(fam_report, cand_df)
    audit.to_csv(out_dir / "crc_axis5_audit.csv", index=False)
    naive_calls, axis5_naive = axis5_naive_calls(candidates, inp["clone"])
    axis5_rows = audit.loc[audit["program_label"] == "axis5_like"]
    axis5_call = str(axis5_rows["v1_final_call"].iloc[0]) if not axis5_rows.empty else "missing"
    after_target = int((fam_report["final_call"] == "target_axis").sum()) if not fam_report.empty else 0
    after_false = after_target
    return {
        "dataset": "visium_hd_crc_stress",
        "benchmark_method": method,
        "n_input_axes": len(candidates),
        "n_axis_families_after_refinement": len(fam_df),
        "benchmark_target_like_calls": naive_calls,
        "origin_ax_target_calls": after_target,
        "benchmark_false_target_calls": naive_calls,
        "origin_ax_false_target_calls": after_false,
        "truth_axis_hits_before": "",
        "truth_axis_hits_after": "",
        "strict_positive_found": "",
        "off_target_rejected": axis5_call == "not_target_axis",
        "false_call_reduction": naive_calls - after_false,
        "conclusion": f"Axis-5-like naive_call={axis5_naive}; ORIGIN-Ax call={axis5_call}; CRC target families remain {after_target}",
    }


def run_dataset_method(inp: dict, method: str) -> dict:
    candidates = make_benchmark_candidates(inp["x"], inp["genes"], inp["gene_weights"], method, inp["k"])
    cand_df, fam_df, _ = refine_candidates(
        dataset=inp["dataset"],
        method=method,
        candidates=candidates,
        genes=inp["genes"],
        coords=inp["coords"],
        clone=inp["clone"],
        niche=inp["niche"],
        gene_weights=inp["gene_weights"],
        truth_eval_genes=inp["truth_eval_genes"] if inp["truth_eval_genes"] else None,
        attribution_valid=inp["attribution_valid"],
        similarity_threshold=OriginAxConfig().similarity_threshold,
    )
    if inp["dataset"] == "benchmark_pseudo_st_positive":
        return summarize_pseudo(method, candidates, fam_df, inp)
    if inp["dataset"] == "benchmark_real_xenium_myeloid":
        return summarize_real(method, candidates, fam_df, inp)
    if inp["dataset"] == "benchmark_visium_hd_crc_stress":
        return summarize_crc(method, candidates, fam_df, cand_df, inp)
    raise ValueError(inp["dataset"])


def write_markdown(summary: pd.DataFrame) -> None:
    path = OUT / "BENCHMARK_REFINEMENT_SUMMARY.md"
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("# Benchmark Refinement Summary\n\n")
        fh.write("ORIGIN-Ax is applied on top of benchmark-generated axes. In this experiment, ICA-only, NMF-only, and cNMF-like repeated NMF axes are treated as external benchmark candidate programs; ORIGIN-Ax then performs axis-family grouping, origin-aware scoring, and off-target rejection.\n\n")
        fh.write("ORIGIN-Ax does not replace ICA, NMF, or cNMF-like decomposition. It refines their output by adding target-origin evidence, off-target rejection, and family-level interpretation.\n\n")
        fh.write("If pseudo-ST truth recovery is unchanged but false target calls decrease, this is still a successful refinement outcome because the goal is not rediscovery from scratch.\n\n")
        fh.write("The CRC stress test is kept as a conservative stress test. If it has no malignant target axis after refinement, thresholds are not tuned and Axis-5-like is not called malignant.\n\n")
        fh.write("## Summary Table\n\n")
        fh.write(summary.to_csv(index=False))
        fh.write("\n## Prohibited Interpretations\n\n")
        fh.write("- Do not claim raw ICA/NMF are the best benchmarks across the field.\n")
        fh.write("- Do not claim ORIGIN-Ax beats all methods.\n")
        fh.write("- Do not claim discovery of a CRC malignant axis.\n")
        fh.write("- Do not call Axis-5-like malignant.\n")
        fh.write("- Do not call F2 a target axis.\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pseudo-path", default="data/tumor_st/xenium_melanoma/processed.h5ad")
    parser.add_argument("--pseudo-bins", type=int, default=800)
    parser.add_argument("--pseudo-genes", type=int, default=350)
    parser.add_argument("--pseudo-k", type=int, default=5)
    parser.add_argument("--real-path", default="data/tumor_st/xenium_melanoma/processed.h5ad")
    parser.add_argument("--real-neighborhoods", type=int, default=4000)
    parser.add_argument("--real-neighbor-cells", type=int, default=25)
    parser.add_argument("--real-k", type=int, default=6)
    parser.add_argument("--crc-base", default=str(DEFAULT_B))
    parser.add_argument("--crc-bins", type=int, default=2500)
    parser.add_argument("--crc-genes", type=int, default=800)
    parser.add_argument("--crc-k", type=int, default=8)
    parser.add_argument("--crc-clone-csv", default="experiments/malignant_axes/malaxis_oa/results/cnv_anchor.csv")
    parser.add_argument("--crc-gene-weight-csv", default="experiments/malignant_axes/malaxis_oa/results/gene_weight_anchor.csv")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    DETAIL.mkdir(parents=True, exist_ok=True)
    methods = ["raw_ICA_only", "NMF_only", "cNMF_like_repeated_NMF"]
    inputs = [pseudo_st_inputs(args), real_positive_inputs(args), crc_inputs(args)]
    rows = []
    for inp in inputs:
        for method in methods:
            rows.append(run_dataset_method(inp, method))
    summary = pd.DataFrame(rows)
    summary.to_csv(OUT / "benchmark_refinement_summary.csv", index=False)
    write_markdown(summary)
    print(summary.to_string(index=False))
    print(OUT / "benchmark_refinement_summary.csv")
    print(OUT / "BENCHMARK_REFINEMENT_SUMMARY.md")


if __name__ == "__main__":
    main()
