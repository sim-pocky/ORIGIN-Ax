# Paper Supplement Summary

These analyses are paper-level supplements. They do not modify ORIGIN-Ax v1 core scoring, thresholds, clustering, or candidate generation.

## Ablation Findings

- Full ORIGIN-Ax target calls across benchmark rows: 8.
- Full ORIGIN-Ax false target calls across benchmark rows: 0.
- Removing the off-target penalty yields 21 false target calls across benchmark rows.
- Candidate-level interpretation is retained as the no-family-refinement baseline; this quantifies the false-call reduction provided by the refinement layer.

## Threshold Sensitivity

The threshold sensitivity table reports target calls, false target calls, and truth hits for fixed score thresholds from 0.10 to 0.30. It is intended as a robustness audit, not as post-hoc threshold tuning.

## Similarity Threshold Sensitivity

The family-similarity table reports how the number of connected-component families changes when the axis graph threshold varies from 0.25 to 0.45.

## Reference-Gene-Set Guidance

- Define target support and off-target references before inspecting final calls.
- Include plausible false-boundary programs, not only canonical cell-type markers. For tumors, this includes normal epithelial, stromal/ECM, endothelial, immune, and platform-specific technical programs.
- Split target genes into anchor and held-out subsets when possible. Anchor genes may guide scoring; held-out genes should only be used for evaluation.
- Treat incomplete off-target references as a failure mode. A target call should be downgraded if the off-target reference lacks known confounders for the tissue.
- Use target-swap controls when a rejected family is biologically coherent. A family rejected under one target definition can be a valid target under another.

## Non-Identifiable Follow-up

A non-identifiable family should trigger an evidence-acquisition decision rather than a biological conclusion. Recommended next steps are: add orthogonal anchors such as CNV or cell labels, improve off-target references, split target genes into held-out validation sets, or report the family as unresolved instead of forcing a target label.
