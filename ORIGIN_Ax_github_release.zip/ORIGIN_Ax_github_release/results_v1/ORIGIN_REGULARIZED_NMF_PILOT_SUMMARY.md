# Origin-Regularized NMF Pilot

This is an enhancement experiment. It does not replace ORIGIN-Ax v1 scoring, thresholds, clustering, or candidate refinement. It tests whether target/off-target evidence can be used as a weak learning-time regularizer before the same ORIGIN-Ax audit.

Regularized NMF update: the component update includes a positive target-gene prior and an off-target penalty. The learned axes are then passed through the unchanged ORIGIN-Ax refinement layer.

## Bottom-line interpretation

This pilot should not be promoted as a main positive result in the current BIBM manuscript. It preserves the pseudo-ST positive and CRC overcall-protection behavior, but it does not improve over standard NMF in the real Xenium myeloid setting. Under the stricter held-out target recovery criterion, the origin-regularized NMF candidate set loses the standard-NMF truth-supported hit and introduces one false target call. Therefore, the current evidence supports keeping ORIGIN-Ax as a post-decomposition refinement layer, while leaving learning-time origin regularization as future work rather than a claimed method upgrade.

## pseudo_st_balanced

| method | reconstruction_error | origin_ax_target_calls | truth_supported_target_hits | false_target_calls | strict_positive_found | stromal_offtarget_rejected | axis5_like_call |
| --- | --- | --- | --- | --- | --- | --- | --- |
| standard_nmf | 0.5732 | 1 | 1 | 0 | False | False |  |
| origin_regularized_nmf | 0.5732 | 1 | 1 | 0 | False | False |  |

## real_xenium_myeloid

| method | reconstruction_error | origin_ax_target_calls | truth_supported_target_hits | false_target_calls | strict_positive_found | stromal_offtarget_rejected | axis5_like_call |
| --- | --- | --- | --- | --- | --- | --- | --- |
| standard_nmf | 0.2872 | 1 | 1 | 0 | True | True |  |
| origin_regularized_nmf | 0.2872 | 1 | 0 | 1 | True | True |  |

## visium_hd_crc_stress

| method | reconstruction_error | origin_ax_target_calls | truth_supported_target_hits | false_target_calls | strict_positive_found | stromal_offtarget_rejected | axis5_like_call |
| --- | --- | --- | --- | --- | --- | --- | --- |
| standard_nmf | 0.6932 | 0 | 0 | 0 | False | False | not_target_axis |
| origin_regularized_nmf | 0.6932 | 0 | 0 | 0 | False | False | not_target_axis |

Interpretation boundary: positive results here support feasibility of origin-aware factor learning, not a new primary decomposition method claim. If this pilot is included in the paper, it should be described as proof-of-concept only.
