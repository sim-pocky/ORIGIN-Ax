# CRC Stress-Test Summary

## Setting

- Dataset: Visium HD CRC stress test
- Candidate axes: standard decomposition candidates grouped into ORIGIN-Ax v1 axis families
- Anchor status: formal CNV anchor is used, but CNV alignment is not allowed to define malignant origin

## Axis-5-Like Program

The Axis-5-like program is a differentiated intestinal / normal epithelial-like program.

- `top_genes`: `TSPAN1, CA4, SLC26A3, CLCA4, DUOX2, KRT20, SELENOP, GUCA2A, CEACAM7, PHGR1, GUCA2B, MUC3A`
- `v1_family_label`: `normal_epithelial_like`
- `v1_final_call`: `off_target_axis`

## Naive Overcall Risk

Naive rules would call the Axis-5-like program malignant-like:

- `epithelial_marker_rule`: True
- `cnv_association_rule`: True
- `high_cnv_presence_rule`: True
- `naive_malignant_like_call`: True

ORIGIN-Ax v1 prevents this false call by keeping the program as `normal_epithelial_like / off_target_axis`.

## Allowed Interpretation

Under the current candidates and anchors, there is no safely interpretable malignant-origin axis family in this CRC stress test.

## Prohibited Interpretation

Do not write that CRC lacks malignant biology. Do not write that this experiment discovers a CRC malignant axis. Do not claim clone/niche causal attribution in CRC from these outputs.
