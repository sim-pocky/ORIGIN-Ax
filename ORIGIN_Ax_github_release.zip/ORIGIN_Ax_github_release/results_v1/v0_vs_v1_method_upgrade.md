# v0 to v1 Method Upgrade

## v0

MalAxis-OA v0 is a single-axis gate-based validation layer.

- Input: candidate axes from a limited decomposition run
- Logic: apply gates after axis extraction to decide whether an axis can be interpreted
- Main role: prevent unsupported malignant-axis claims

## v1

ORIGIN-Ax v1 is a multi-candidate origin-constrained graph refinement framework.

- Input: candidate axes from standard decompositions
- Graph construction: combine expression similarity with origin compatibility and target/off-target conflict penalties
- Refinement: cut axis families from the origin-constrained graph, not from expression similarity alone
- Evidence: combine target-origin support, off-target rejection, consensus support, held-out audit, and optional anchors
- Output: target, off-target, downgraded, or non-identifiable axis families

## Added Value

1. Multi-decomposition candidate axes

ORIGIN-Ax v1 uses candidates from ICA, NMF, high-target-evidence subset ICA, and high-target-evidence subset NMF.

2. Origin-constrained axis family graph

Candidate axes are not grouped solely by loading correlation and top-gene overlap. The edge weight now includes origin compatibility and conflict penalties:

`W_ij = S_ij + rho * C_origin_ij - kappa * H_conflict_ij`.

This changes family construction before scoring.

3. Identifiability-aware family decision

Each family reports an identifiability margin between target evidence and the strongest competing off-target source. Families with unresolved target/off-target evidence are downgraded instead of forced into a target label.

4. Real-positive target family F0

In real Xenium melanoma neighborhoods, F0 is a strict myeloid/inflammatory target family with held-out target gene overlap.

5. Off-target rejection F1

In the same real-positive experiment, F1 is a malignant-melanoma-like family and is rejected as `not_target_axis`.

6. CRC Axis-5-like false-call prevention

In the Visium HD CRC stress test, a naive epithelial/CNV rule would overcall the Axis-5-like program as malignant-like, while ORIGIN-Ax v1 keeps it off target.

## Positioning

ORIGIN-Ax v1 does not replace standard decompositions. It refines their outputs on an origin-constrained candidate-axis graph so that axis families can be interpreted, downgraded, or rejected with explicit biological support.
