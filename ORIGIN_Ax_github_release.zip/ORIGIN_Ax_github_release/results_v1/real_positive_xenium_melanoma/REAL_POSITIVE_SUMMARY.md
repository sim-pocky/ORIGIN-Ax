# Real Positive Xenium Melanoma Summary

This experiment uses real Xenium melanoma neighborhoods and a myeloid/inflammatory target definition.

## Main Strict Positive

F0 is the strict real-positive target family under the origin-constrained graph refinement output.

- `family_id`: F0
- `final_call`: `target_axis`
- `heldout_target_gene_overlap`: 4
- `max_offtarget_source`: none
- `strict_positive`: True
- Representative top genes: CXCL10, HLA-DPB1, FCER1G, LYZ, CCL5, SERPING1, CD68, IRF1, COTL1

Held-out target genes are used for audit, not for primary origin scoring.

## Off-Target Rejection

F1 is rejected as a malignant-melanoma-like off-target family.

- `family_id`: F1
- `final_call`: `not_target_axis`
- `max_offtarget_source`: malignant_melanoma
- Representative top genes: TYRP1, PMEL, TYR, MLANA, TRPM1

This shows that ORIGIN-Ax does not simply accept all coherent Xenium families as myeloid target axes.

## Important Change From Earlier Output

After adding origin-constrained graph refinement, family IDs changed relative to the previous expression-only graph version. The main real-positive family is now F0, not the earlier F1 label. This is expected because origin evidence now participates in family construction rather than only in post-hoc scoring.

## Allowed Claim

ORIGIN-Ax identifies one strict real-positive myeloid/inflammatory family in Xenium melanoma neighborhoods and rejects one forbidden off-target family in the same experiment.

## Prohibited Claims

- Do not claim all inflammatory families are recovered.
- Do not claim malignant melanoma programs are myeloid targets.
- Do not claim this experiment proves universal target recovery across all decompositions.
