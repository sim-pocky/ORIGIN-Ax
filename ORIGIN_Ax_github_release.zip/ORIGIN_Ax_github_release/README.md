# ORIGIN-Ax

ORIGIN-Ax is a post-decomposition origin-constrained graph refinement framework
for interpretable latent axes in spatial transcriptomics. It takes candidate
axes from upstream decompositions such as ICA, NMF, or repeated NMF and refines
them into origin-consistent axis families with auditable labels:
`target_axis`, `off_target`, or `non_identifiable`.

This repository snapshot contains the code, small result tables, and LaTeX
paper source used for the current manuscript draft. Raw spatial transcriptomics
matrices are not included.

## Repository Layout

- `origin_ax/`: core implementation and experiment scripts.
- `results_v1/`: small CSV/Markdown result summaries used by the paper.
- `paper/`: IEEE LaTeX source, figure-generation script, and generated figures.
- `paper_assets/`: compact plotting inputs used to build paper figures.

## Minimal Environment

Python 3.10+ is recommended.

```bash
pip install -r requirements.txt
```

Optional real-data scripts require local access to the processed Xenium melanoma
and Visium HD CRC data used in the manuscript. The controlled and summary-check
scripts do not require redistributing raw matrices.

## Common Commands

Run the controlled positive:

```bash
python origin_ax/run_positive_control_v1.py
```

Run final consistency checks on included result tables:

```bash
python origin_ax/check_final_results.py
```

Regenerate paper figures:

```bash
python paper/make_paper_figures.py
```

## Notes on Claims

Unsupported target-like promotions are predefined claim-risk audit events, not
absolute biological false-positive labels. ORIGIN-Ax provides claim control
under the specified target/off-target reference universe and does not perform
expression decontamination, infer true cell-of-origin, or replace upstream
decomposition.

